function [optsol, output] = scvxChambollePockSolver(objFunc, linOper, x0, ...
                                       options, varargin)
% ADMM. The variables here are a bit different because we are using a
% different formulation. For all the other algorithms, I am using the first
% formulation in my document admmpart.pdf. In ADMM, I am using the
% formulation that Quoc explained to me.


% Get time started.
fprintf('******** The Chambolle-Pock primal-dual algorithm ********\n');
time1      = tic;

% Print the information and initialize the history list.
ASGARD_printInfo();
ASGARD_initHistory;

% Get data from inputs.
nx          = objFunc.nx;
proxFxOper  = objFunc.fxProxOper;
proxGxOper  = objFunc.gxProxOper;
proxFsOper  = @(x, gamma, varargin) ( x - gamma*proxFxOper(x/gamma, 1/gamma, varargin{:}) );
fxFunc      = objFunc.fxFunc;
gxFunc      = objFunc.gxFunc;
Aoper       = linOper.Aoper;
AToper      = linOper.AToper;
FxFunc      = @(x, varargin) fxFunc(Aoper(x), varargin{:}) + gxFunc(x, varargin{:});        
muhy        = 0;
if isfield(objFunc, 'muhy'), muhy = objFunc.muhy; end
if muhy > 0, fprintf('This is the strongly convex case\n'); end

% % Evaluate the l2-norm of AT*A.
LA_bar      = options.LA_bar;

% Set parameter.
tau_cur     = 0.5/sqrt(LA_bar);
if muhy > 0, tau_cur = 1.0/sqrt(LA_bar); end
sigma0      = tau_cur;
sigma_cur   = tau_cur;
theta_cur   = 1;

% Initialization.

x_cur       = x0;
y0          = zeros(size(Aoper(x0)));
y_cur       = y0;
z_cur       = x0;
x_avg       = zeros(size(x_cur));
y_avg       = zeros(size(y_cur));
weights     = 0;

% The main loop.
for iter = 1:options.MaxIters
    
    % Start counting cummulative time.
    time_it = tic;
    
    % Evaluate the objective value.
    if options.isFxEval
        incr    = sigma_cur/sigma0;
        weights = weights + incr;
        omega   = incr/weights;
        x_avg   = (1 - omega)*x_avg + omega*x_cur;
        y_avg   = (1 - omega)*y_avg + omega*y_cur;
        fx_val  = FxFunc(x_avg, varargin{:}); 
    end
    
    % The main step.
    y_next       = proxFsOper(y_cur + sigma_cur * Aoper(z_cur), sigma_cur);
    x_next       = proxGxOper(x_cur  - tau_cur * AToper(y_next), tau_cur);
    z_cur        = x_next + theta_cur * (x_next - x_cur);
    
    % Compute the feasibility.
    abs_pfeas     = norm(y_next(:) - y_cur(:), 2);
    rel_pfeas     = abs_pfeas/max(norm(y_cur(:), 2), 1);
    
    % Compute the solution change.
    abs_schg      = norm(x_next(:) - x_cur(:), 2);
    rel_schg      = abs_schg/max(1, norm(x_cur(:), 2));
    
    % Print the iteration and save the iteration history.
    ASGARD_printIteration;
    ASGARD_saveHistory;
    
    % Check the stopping criterion.
    if options.isStoppingCond
        if rel_schg <= options.RelTolX && rel_pfeas <= options.RelTolFeas && iter > 1
            output.status = 'Convergence achieved';
            output.msg    = ['The serarch direction norm and the ', ...
                             'feasibility gap is below the desired threshold'];
            x_cur        = x_next;
            y_cur        = y_next;
            break;
        end
    end
    
    % Move the the next iteration.
    x_cur        = x_next;
    y_cur        = y_next;
end
% End of the main loop.

% Finalization phase.
ASGARD_finalization;

% Get the final solution.
optsol.x_opt  = x_cur;
optsol.y_opt  = y_cur;
optsol.fx_val = fx_val;

end

