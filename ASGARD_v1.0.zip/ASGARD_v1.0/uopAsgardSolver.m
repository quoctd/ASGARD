% FUNCTION: [optsol, output] = uopAsgardSolver(objFunc, linOper, beta1, x0, options, varargin)
% PURPOSE: An implementation of the ASGARD algorithm for solving 
%          unconstrained convex optimization problems of the form:
%                    min_x f(x) + g(Ax).
%
% USAGE:
%    Inputs:
%      objFunc     : A structure that contains f, the proximal operator of f
%                    and g^*, and additional fields if needed.
%      linOper     : A structure to store the linear operators A and its adjoints.
%      x0          : An initial point
%      options     : Optional variables to control the algorithm.
%      varargin    : User defined variables if needed.
%
%    Outputs:
%      optsol      : A structure to contain the final solution.
%      output      : A structure to store other output information.
%
% REFFERENCES:
%    [1]. Q. Tran-Dinh, O. Fercoq, and V. Cevher, A Smoothing Primal-Dual 
%         Optimization Framework for Fully Nonsmooth Constrained Convex 
%         Optimization, Manuscript, 2016.
%
% INFORMATION:
%    By Quoc Tran-Dinh, Department of Statistics and Operations Research
%    The University of North Carolina at Chapel Hill (UNC).
%    Joint work with Olivier Fercoq, and Volkan Cevher.
%    Date: 08.26.2016.
%    Last modified: 08.06.2016.
%    Contact: quoctd@email.unc.edu
%
function [optsol, output] = uopAsgardSolver(objFunc, linOper, x0, options, varargin)
   
% Check the inputs.
if nargin < 2,        error('Not enough inputs');       end;
if nargin < 4,        options = ASGARD_OptimSet([]);    end;
if nargin < 3,        x0      = [];                     end;
if isempty(options),  options = ASGARD_OptimSet([]);    end;
if ~isstruct(linOper),   error('Invalid second input'); end
if ~isstruct(objFunc),   error('Invalid first input');  end

% Get time started.
time1      = tic;

% Print the information and initialize the history list.
options    = ASGARD_OptimSet( options );
ASGARD_printInfo();
ASGARD_initHistory;

% Get data from inputs.
nx         = objFunc.nx;
fxProxOper = objFunc.fxProxOper;
cgProxOper = objFunc.cgyProxOper;
fxFunc     = objFunc.fxFunc;
mx         = linOper.mx;
Aoper      = @(x) linOper.Aoper( x, varargin{:});
AToper     = @(x) linOper.AToper(x, varargin{:});
LA_bar      = options.LA_bar;
beta1       = options.beta1;
% Evaluate the l2-norm of AT*A.
% LA_bar     = ASGARD_l2NormEval(nx, Aoper, AToper, ...
%              options.PwMaxIters, options.PwRelTol);
        
% Generate an initial point.
if isempty(x0), x0 = zeros(nx, 1); end

% Initialization phase.
x_cur      = x0;
x_hat      = x_cur;
y_dot      = zeros(mx, 1);
%beta1      = 0.5*options.TradeOffFact*sqrt(LA_bar);
Lby        = 1;
tau        = 1;
beta       = beta1;
Ax_cur     = Aoper(x_cur);
Ax_hat     = Ax_cur;
y_hat_star = y_dot;

% The main loop.
for iter = 1:options.MaxIters
    
    % Start counting cummulative time.
    time_it = tic;
    
    % Evaluate the objective value if required.
    if options.isFxEval, fx_val = fxFunc(x_cur, options, varargin{:}); end
    
    % Compute the step-size tau.
    p3tau      = roots([1 / Lby, 1, tau^2, -tau^2]);
    tau_next   = real(p3tau(3)); 

    % Compute the dual vector y_hat_star.
    y_hat_old  = y_hat_star;
    y_hat_star = cgProxOper(y_dot + (1/beta)*Ax_hat, 1/beta );
    
    % Compute the proximal operator of f and compute Ax_next.
    betaL      = beta/LA_bar;
    Aty_hats   = AToper(y_hat_star);
    x_next     = fxProxOper( x_hat - betaL*Aty_hats, betaL );
    Ax_next    = Aoper(x_next);
    
    % Update vector x_hat and Ax_hat.
    x_hat      = x_next  + ((tau_next * (1 - tau))/tau) * (x_next  - x_cur);
    Ax_hat     = Ax_next + ((tau_next * (1 - tau))/tau) * (Ax_next - Ax_cur);
    
    % Compute the solution change (absolute and relative changes).
    abs_schg   = norm(x_next - x_cur, 2);
    rel_schg   = abs_schg/max(1, norm(x_cur, 2));
    
    % Compute the feasibility gap (absotule and relative).
    abs_pfeas  = norm( y_hat_star - y_hat_old, 2);
    rel_pfeas  = abs_pfeas/max(1, norm(y_hat_star, 2));
    
    % Print the iteration and save the iteration history.
    ASGARD_printIteration;
    ASGARD_saveHistory;
    
    if iter == options.MaxIters
        break;
    end
    % Check the terminated condition.
    if 0
    if rel_schg <= options.RelTolX && rel_pfeas <= options.RelTolFeas && iter > 1 
        output.status = 'Convergence achieved';
        output.msg    = ['The serarch direction norm and the ', ...
                         'feasibility gap is below the desired threshold'];
        x_cur         = x_next;
        break;
    end
end
    
    % Update the second smoothness parameter beta.
    beta      = beta/(1 + tau_next/Lby);
   
    % Perform Restarting if required.
    if options.isRestart
        if mod(iter, options.nRestart) == 0
            x_hat     = x_next;
            Ax_hat    = Ax_next;
            y_dot     = y_hat_star;
            beta      = beta1;
            tau_next  = 1.0;
        end
    end
    if iter == options.MaxIters
        break;
    end
    % Assign variables to go to the next step.
    tau       = tau_next;
    x_cur     = x_next;
    Ax_cur    = Ax_next;
end
% End of the main loop.

% Finalization.
ASGARD_finalization;

% Get the final solution.
optsol.x_opt  = x_cur;
optsol.y_opt  = y_hat_star;
optsol.fx_val = fx_val;
output.final_beta=beta;
end

% ASGARD v.1.0 by Quoc Tran-Dinh (quoctd@email.unc.edu)
% Joint work with Olivier Fercoq, and Volkan Cevher.
% Copyright @ 2016 Department of Statistics and Operations Research (STOR)
%                The University of North Carolina at Chapel Hill (UNC)
% See the file LICENSE for full license information.