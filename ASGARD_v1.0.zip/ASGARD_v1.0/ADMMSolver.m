function [optsol, output] = ADMMSolver(objFunc, linOper, x0, rho0, options, varargin)
% ADMM. The variables here are a bit different because we are using a
% different formulation. For all the other algorithms, I am using the first
% formulation in my document admmpart.pdf. In ADMM, I am using the
% formulation that Quoc explained to me.

% Get time started.
time1      = tic;

% Print the information and initialize the history list.
options    = ASGARD_OptimSet( options );
ASGARD_printInfo();
ASGARD_initHistory;

nx          = objFunc.nx;
nu          = objFunc.nu;
proxFxOper  = objFunc.proxFxOper;
fxFunc      = objFunc.fxFunc;
Aoper       = linOper.Aoper;
AToper      = linOper.AToper;
Doper       = linOper.Doper;
DToper      = linOper.DToper;
cb          = linOper.cb;
m           = length(cb);
nrm_b       = max(norm(cb, 2), 1);

x_cur   = x0(1:nx);
u_cur   = x0(nx+1:nx+nu);
v_cur   = x_cur;

y1_cur  = zeros(m, 1);
y2_cur  = zeros(nu,1);
y3_cur  = zeros(nx,1);

% The penalty parameter.
rho     = rho0;

% Define a linear operator for conjugate gradient.
Moper   = @(x) AToper(Aoper(x)) + DToper(Doper(x)) + x;

% The main loop.
for iter = 1:options.MaxIters
    
    % Start counting cummulative time.
    time_it = tic;
    
    % Evaluate the objective value.
    if options.isFxEval, fx_val = fxFunc(x_cur, varargin{:}); end
    
    % Update the primal step.
    irho           = 1/rho;
    x_next         = irho*y3_cur + v_cur;
    [v_next, flag] = pcg(Moper, AToper(cb - irho*y1_cur) + DToper(u_cur - irho*y2_cur) + x_next - irho*y3_cur);
    u_next         = proxFxOper(irho*y2_cur + Doper(v_next), irho);

    % Update the multipliers.
    feas_x        = Aoper(v_next) - cb;
    feas_u        = Doper(v_next) - u_next;
    feas_v        = v_next - x_next;
    
    % Compute the feasibility.
    abs_pfeas     = norm([feas_x(:); feas_u(:); feas_v(:)], 2);
    rel_pfeas     = abs_pfeas/nrm_b;
    
    % Compute the solution change.
    abs_schg      = norm([x_next(:) - x_cur(:); u_next(:) - u_cur(:); v_next(:) - v_cur(:)], 2);
    rel_schg      = abs_schg/max(1, norm([x_cur(:); u_cur(:); v_cur(:)], 2));
    
    % Print the iteration and save the iteration history.
    ASGARD_printIteration;
    ASGARD_saveHistory;
    
    % Check the stopping criterion.
    if rel_schg <= options.RelTolX && rel_pfeas <= options.RelTolFeas && iter > 1
        output.status = 'Convergence achieved';
        output.msg    = ['The serarch direction norm and the ', ...
                         'feasibility gap is below the desired threshold'];
        x_cur = x_next; 
        u_cur = u_next; 
        v_cur = v_next;
        break;
    end
    
    % Update the multiplier.
    y1_cur        = y1_cur + rho*feas_x;
    y2_cur        = y2_cur + rho*feas_u;
    y3_cur        = y3_cur + rho*feas_v;

    % Move the the next iteration.
    x_cur = x_next; 
    u_cur = u_next; 
    v_cur = v_next;
end
% End of the main loop.

% Finalization phase.
ASGARD_finalization;

% Get the final solution.
optsol.x_opt  = x_cur;
optsol.u_opt  = u_cur;
optsol.v_opt  = v_cur;
optsol.fx_val = fx_val;

end

