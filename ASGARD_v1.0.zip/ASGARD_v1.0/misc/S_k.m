clear all
close all

maxiter         = 1e5;
tau             = 1;
beta            = 10;
S_k             = zeros(maxiter, 1);

for ii = 1:maxiter
   p3tau        = roots([1, 1, 0, -tau^2]);
   tau          = p3tau(3);
   beta_old     = beta;
   s_k          = tau^2 * beta_old / (1 + tau);
   S_k(ii+1)    = (1 - tau)*S_k(ii) + s_k;
   beta         = beta / (1 + tau);
end

figure, loglog(S_k)
grid on


