% Example 3: Group weighted basis pursuit problem:
%
%            min_x sum_{i=1}^Nw_i|x_i|_2 s.t. Ax = b.
%
% where the weight vector w = (w_1, ..., w_N) is positive.
clear all
%% Generate data.

% Problem size.
scale    = 1;
p        = scale*1000;
n        = scale*300; 
s        = scale*100; 
p12      = round(p/2);
N        = round(scale*10);
w        = rand(N, 1);
sigma    = 0;
thresh   = @(x, r) sign(x).*max(abs(x) - r, 0);

% Generate matrix A.
cor_tau  = 0.5;
if cor_tau > 0
  var0 = (1 - cor_tau)^2 / (1 - cor_tau^2); %initial variance
  A = zeros(n, p);
  A(:,1) = sqrt(var0)*randn(n, 1);
  for kk = 2:p
    A(:,kk) = cor_tau*A(:,kk-1) + (1 - cor_tau)*(randn(n,1));
  end
else
    A   = randn(n, p);
end

% Generate vector c.
x_org    = zeros(p, 1);
T        = randsample(n, s);
x_org(T) = randn(s, 1);
noise    = thresh( randn(n, 1), 100);
subrows  = randperm(p, n);
Aoper    = @(x) A*x; %LinearOperator(x, p, subrows, 0);
AToper   = @(y) A'*y; %LinearOperator(y, p, subrows, 1);
yb       = Aoper(x_org) + sigma*noise;

%% Define the proximal operators.
subrows      = randperm(p, n);
objFunc.nx  = p;
objFunc.fxProxOper = @(x, t, varargin) l2wGroupNormProx(x, t, w, N); 
objFunc.fxFunc     = @(x, varargin)    l2wGroupNormFunc(x, w, N);

linConstr.Aoper    = @(x, varargin) Aoper(x);
linConstr.AToper   = @(y, varargin) AToper(y);
linConstr.cb       = yb;

% Generate an initial point.
x0 = ones(p, 1);

%% Define optional parameters.
options              = ASGARD_OptimSet([]);
options.MaxIters     = 5000;
options.RelTolFeas   = 1e-6;
options.RelTolX      = 1e-5;
options.saveHistMode = 2;
options.isRestart    = 0;
options.nRestart     = 100;
options.TradeOffFact = 1;

% Call the ASGARD solver.

% [optsol2, output2] = ASGARD_Solver(objFunc, linConstr, x0, options);
[optsol2, output2] = copAsgardSolver(objFunc, linConstr, x0, options);



%% Call the ADSGARD solver.
% [optsol3, output3] = ADSGARD_Solver(objFunc, linConstr, x0, options);
[optsol3, output3] = copAdsgardSolver(objFunc, linConstr, x0, options);

%% Plot the results
figure;
semilogy(output2.hist.fx_val); xlabel('The objective value');
hold on,
semilogy(output3.hist.fx_val); xlabel('The objective value');
legend('asgard', 'adsgard')

figure;
semilogy(output2.hist.rel_pfeas); xlabel('The feasibility');
hold on,
semilogy(output3.hist.rel_pfeas); xlabel('The feasibility');
legend('asgard', 'adsgard')
% figure(3);
% stairs(x, 'b--'); hold on; stairs(optsol.x_opt, 'r-.');



