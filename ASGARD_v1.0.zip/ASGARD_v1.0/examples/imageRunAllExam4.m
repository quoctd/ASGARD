% Run the Image Reconstruction Example.
result_path = '/Users/quoctd/Dropbox/MyResearch/MatlabCodes/ASGARD/results/';

% Run all algorithm.
isRunAlg                = [1, 1, 1, 1, 1, 1, 1, 1, 1];
options                 = ASGARD_OptimSet([]);

% Run Image 1.
%file_name               = 'im1_MRI_hip';
%file_name               = 'im2_MRI_of_Knee';
file_name               = 'im7_body';
lambda                  = 4.0912e-04; % With and without noise

% Load the real image data.
data_opt                = 4;
imaddress               = [file_name, '.jpg']; %
small_data_size         = [16, 16]; % optional, only required if 3 is chosen above
nresize                 = [];
[x_original, ind, m, n] = get_dataset(data_opt, small_data_size, imaddress, nresize);                                
x_original              = real(x_original);
cb                      = fft2fwd(x_original, ind, m, n);

% % Run all algorithms without counting time.
% noiseVar                = 0; % Without noise.
% options.saveHistMode    = 4;
% options.Verbosity       = 2;
% options.isFxEval        = 1;
% imageRunAll(); 
% save([result_path, file_name, '_without_noise_without_time.mat']);

% Run all algorithms with counting time.
noiseVar                = 0; % Without noise.
options.saveHistMode    = 0;
options.Verbosity       = 0;
options.isFxEval        = 0;
imageRunAll(); 
save([result_path, file_name, '_without_noise_with_time.mat']);
 
% % Run all algorithms without counting time.
% noiseVar                = 1e-3; % With noise.
% cb                      = cb + noiseVar*wgn(size(cb,1), size(cb,2), 5, 'real');  %%% Add Poisson noise ....
% options.saveHistMode    = 4;
% options.Verbosity       = 2;
% options.isFxEval        = 1;
% imageRunAll(); 
% save([result_path, file_name, '_with_noise_without_time.mat']);
% 
% % Run all algorithms with counting time.
% noiseVar                = 1e-3; % With noise.
% cb                      = cb + noiseVar*wgn(size(cb,1), size(cb,2), 5, 'real');  %%% Add Poisson noise ....
% options.saveHistMode    = 0;
% options.Verbosity       = 0;
% options.isFxEval        = 0;
% imageRunAll(); 
% save([result_path, file_name, '_with_noise_with_time.mat']);

