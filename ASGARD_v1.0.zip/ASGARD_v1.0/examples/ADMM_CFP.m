% FUNCTION: [xopt, output] = ADMM_CFP(prob, v0, lbd0, rho, opts)
% PURPOSE: The implementation of ADDM to solve the convex feasibility problem
%
function [xopt, output] = ADMM_CFP(prob, v0, lbd0, rho, opts)
    
    % Initialization.
    time1   = tic;
    projC1  = prob.projC1;
    projC2  = prob.projC2;
    v_cur   = v0;
    lbd_cur = lbd0;
    ub_cur  = zeros(size(v0));
    vb_cur  = zeros(size(v0));
    
    % The main loop.
    for iter = 1:opts.maxiter
        
        % Update the main iteration.
        u_next   = lbd_cur - v_cur  - (1/rho)*projC1(rho*(lbd_cur - v_cur));
        v_next   = lbd_cur - u_next - (1/rho)*projC2(rho*(lbd_cur - u_next));
        lbd_next = lbd_cur - (u_next + v_next);
        
        % Compute the average sequence.
        ub_cur   = (iter-1)/iter*ub_cur + (1/iter)*u_next;
        vb_cur   = (iter-1)/iter*vb_cur + (1/iter)*v_next;
        n_feas2  = norm(ub_cur + vb_cur, 2);
        
        % Check the stopping criterion.
        dlbd = lbd_next - lbd_cur;
        nrm_feas = norm(dlbd, 2);
        rel_feas = nrm_feas;%/max(norm(lbd_cur, 2), 1);
        
        output.hist.feas(iter, 1)      = nrm_feas;
        output.hist.rel_feas(iter, 1)  = rel_feas;
        output.hist.feas2(iter, 1)     = n_feas2;
        
        fprintf('Iter = %4d, relFeas = %3.3e, relAvgFeas = %3.3e\n', iter, rel_feas, n_feas2);
        
        if rel_feas <= opts.tolx
            output.msg = 'Convergence acchieved!';
            break;
        end
        
        % Assign to the next iteration.
        v_cur   = v_next;
        lbd_cur = lbd_next;
    end
    
    % Get the final solution.
    xopt            = u_next;
    output.iter     = iter;
    output.feas     = nrm_feas;
    output.feas2    = n_feas2;
    output.rel_feas = rel_feas;
    output.time     = toc(time1);
end