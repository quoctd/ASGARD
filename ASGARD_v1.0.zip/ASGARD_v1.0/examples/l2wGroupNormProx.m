function y = l2wGroupNormProx(x, gamma, w, N)

    ni = length(x)/N;
    y  = [];
    for i=1:N
        xi     = x(1:ni,1);
        x      = x(ni+1:end,1);
        nrm_xi = norm(xi, 2);
        yi     = max(nrm_xi - gamma*w(i,1), 0)*xi/nrm_xi;
        y      = [y; yi];
    end
    
end