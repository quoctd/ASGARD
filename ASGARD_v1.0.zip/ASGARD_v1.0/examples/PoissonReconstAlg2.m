function [optsol, output] = PoissonReconstAlg2(inputs, U0, options, varargin)

px  = inputs.px; 
py  = inputs.py;
nx  = px*py;
if nargin < 3,       options = ASGARD_OptimSet([]); end
if isempty(options), options = ASGARD_OptimSet([]); end

% Generate data.
b      = inputs.Yf(:);
Loper  = @(u) vec( inputs.Loper( reshape(u, px, py) ) );
LToper = Loper;

% Generate the initial point.
U0     = U0(:);
S0     = Loper(U0);
x0     = [U0; S0];

% Define the proximal operator of TV norm.
Tv_prox  = @(x, gamma) vec( chambolle_prox_TV_stop(reshape(x, px, py), gamma) );
Tv_feval = @(x) Tv_norm_eval( x, px, py );

% Define the inputs for solver.    
objFunc.nx         = length(x0);
objFunc.fxProxOper = @(x, gamma, varargin) fxProxOper(x, gamma, b, inputs.lambda, nx, Tv_prox);
objFunc.fxFunc     = @(x, varargin) fxEval(x, b, inputs.lambda, nx, Tv_feval);

linConstr.Aoper    = @(x, varargin) AxOper(x, Loper, nx);
linConstr.AToper   = @(y, varargin) ATxOper(y, LToper);
linConstr.cb       = zeros(length(S0),1);

% Call the solver.
[optsol, output] = ASGARD_Solver(objFunc, linConstr, x0, options, varargin{:});
   
end

% Define the linear operator.
function y = AxOper(x, Loper, nx)
    u  = x(1:nx,1);
    s  = x(nx+1:end,1);
    y  = Loper(u) - s;
end

% Define the adjoint of the linear operator.
function x = ATxOper(y, LToper)
    x  = [LToper(y); -y];
end

% Define the prox-function of the objective.
function px = fxProxOper(x, gamma, b, lambda, nx, Tv_prox)

    u  = x(1:nx,1); 
    s  = x(nx+1:end,1); 
    px = [Tv_prox(u, gamma*lambda); 0.5*(sqrt((gamma - s).^2 + 4*gamma*b) - (gamma - s))];

end

% Evaluate the objective value.
function fx = fxEval(x, b, lambda, nx, Tv_feval)

    u  = x(1:nx,1); 
    s  = x(nx+1:end,1); 
    fx = sum( s - b.*log(s) ) + lambda*Tv_feval(u);

end

% Evaluate the TV-norm.
function fx = Tv_norm_eval( x, px, py )
    
% Compute the gradient of the images.
    X  = reshape(x, px, py);
    Dx = [diff(X,1,2), X(:,1) - X(:,end)];
    Dy = [diff(X,1,1); X(1,:) - X(end,:)];
    fx = norm([Dx(:); Dy(:)], 1);
    
end
