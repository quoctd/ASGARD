%% Example: Quadratic programming:
%
%          min 0.5*y'*Q*y + q'*y s.t. lbx <= B*y <= ubx.
%
%  Here, Q in R^{pxp} is symmetric positive semidefinite, B in R^{nxp},
%  q in R^p, and lbx, ubx in R^n.
%

p       = 500;
n       = 500;
mu_Q    = 0;
width_r = 1;

R       = randn(p,round(p/2)+1);
Q       = R*R'/p + mu_Q*eye(p);
q       = randn(p,1);

B       = randn(n, p);
B       = B/sqrt(n);
x_org   = randn(p,1);
lbx     = B*x_org - width_r*rand(n,1);
ubx     = B*x_org + width_r*rand(n,1);
rho_mu  = 0.5*max(mu_Q,0.25)/norm(B,2).^2;
c       = zeros(n,1);

%% Set the optional parameters.
options                = ASGARD_OptimSet([]);
options.isStoppingCond = 0;
options.MaxIters       = 2000;
%options.saveHistMode   = 5;

%% Solve the problem by CVX.
time_cvx = tic;
cvx_solver mosek;
cvx_begin;
    variable y_cvx(p);
    minimize( 0.5*quad_form(y_cvx, Q) + q'*y_cvx );
    subject to
        lbx <= B*y_cvx; B*y_cvx <= ubx;
cvx_end;
time_cvx     = toc(time_cvx);
fx_cvx       = 0.5*y_cvx'*Q*y_cvx + q'*y_cvx - 1e-5;
rel_feas_cvx = norm( min(B*y_cvx    - lbx, 0), 2 ) + norm( max(B*y_cvx    - ubx, 0), 2 );
nrmy_cvx     = max(1, norm(y_cvx, 2));

%% Call the PAPA solver.
options.Algorithm    = 'PAPA';
options.nRestart     = 25;
time1a               = tic;
[optsol1a, output1a] = QpPapaSolver(Q, q, B, lbx, ubx, options, []);
yopt1a               = optsol1a.y_opt;
fx_val1a             = 0.5*yopt1a'*Q*yopt1a + q'*yopt1a;
rel_feas1a           = norm( min(B*yopt1a - lbx, 0), 2 ) + norm( max(B*yopt1a - ubx, 0), 2 );
sol_diff1a           = norm(yopt1a - y_cvx, 2)/nrmy_cvx;
time1a               = toc(time1a);

%% Call the PAPA solver with Restart.
options.Algorithm    = 'PAPA-RS';
options.nRestart     = 25;
time1b               = tic;
[optsol1b, output1b] = QpPapaSolver(Q, q, B, lbx, ubx, options, []);
yopt1b               = optsol1b.y_opt;
fx_val1b             = 0.5*yopt1b'*Q*yopt1b + q'*yopt1b;
rel_feas1b           = norm( min(B*yopt1b - lbx, 0), 2 ) + norm( max(B*yopt1b - ubx, 0), 2 );
sol_diff1b           = norm(yopt1b - y_cvx, 2)/nrmy_cvx;
time1b               = toc(time1b);

%% Call the PAPA solver with Restart.
options.Algorithm    = 'PALPA';
options.nRestart     = 25;
time1c               = tic;
[optsol1c, output1c] = QpPapaSolver(Q, q, B, lbx, ubx, options, []);
yopt1c               = optsol1c.y_opt;
fx_val1c             = 0.5*yopt1c'*Q*yopt1c + q'*yopt1c;
rel_feas1c           = norm( min(B*yopt1c - lbx, 0), 2 ) + norm( max(B*yopt1c - ubx, 0), 2 );
sol_diff1c           = norm(yopt1c - y_cvx, 2)/nrmy_cvx;
time1c               = toc(time1c);

%% Call the PALPA solver with Restart.
options.Algorithm    = 'PALPA-RS';
options.nRestart     = 25;
time1d               = tic;
[optsol1d, output1d] = QpPapaSolver(Q, q, B, lbx, ubx, options, []);
yopt1d               = optsol1d.y_opt;
fx_val1d             = 0.5*yopt1d'*Q*yopt1d + q'*yopt1d;
rel_feas1d           = norm( min(B*yopt1d - lbx, 0), 2 ) + norm( max(B*yopt1d - ubx, 0), 2 );
sol_diff1d           = norm(yopt1d - y_cvx, 2)/nrmy_cvx;
time1d               = toc(time1d);

%% Call the PAPA solver for strong convexity without Restart.
options.Algorithm    = 'PAPA-SCVX';
options.nRestart     = 200;
time1e               = tic;
[optsol1e, output1e] = QpPapaSolver(Q, q, B, lbx, ubx, options, []);
yopt1e               = optsol1e.y_opt;
fx_val1e             = 0.5*yopt1e'*Q*yopt1e + q'*yopt1e;
rel_feas1e           = norm( min(B*yopt1e - lbx, 0), 2 ) + norm( max(B*yopt1e - ubx, 0), 2 );
sol_diff1e           = norm(yopt1e - y_cvx, 2)/nrmy_cvx;
time1e               = toc(time1e);

%% Call the PAPA solver for strong convexity with Restart.
options.Algorithm    = 'PAPA-SCVX-RS';
options.nRestart     = 200;
time1f               = tic;
[optsol1f, output1f] = QpPapaSolver(Q, q, B, lbx, ubx, options, []);
yopt1f               = optsol1f.y_opt;
fx_val1f             = 0.5*yopt1f'*Q*yopt1f + q'*yopt1f;
rel_feas1f           = norm( min(B*yopt1f - lbx, 0), 2 ) + norm( max(B*yopt1f - ubx, 0), 2 );
sol_diff1f           = norm(yopt1f - y_cvx, 2)/nrmy_cvx;
time1f               = toc(time1f);

%% Call Two-loop ASGARD.
options.nRestart     = 25;
options.Algorithm    = '2LASGARD';
time2                = tic;
[optsol2, output2]   = QpAsgardSolver(Q, q, B, c, lbx, ubx, options, []);
yopt2                = optsol2.x_opt;
fx_val2              = 0.5*yopt2'*Q*yopt2 + q'*yopt2;
rel_feas2            = norm( min(B*yopt2 - lbx, 0), 2 ) + norm( max(B*yopt2 - ubx, 0), 2 );
sol_diff2            = norm(yopt2 - y_cvx, 2)/nrmy_cvx;
time2                = toc(time2);

%% Call One-loop ASGARD with Restart.
options.Algorithm    = '1LRASGARD';
time3                = tic;
[optsol3, output3]   = QpAsgardSolver(Q, q, B, c, lbx, ubx, options, []);
yopt3                = optsol3.x_opt;
fx_val3              = 0.5*yopt3'*Q*yopt3 + q'*yopt3;
rel_feas3            = norm( min(B*yopt3 - lbx, 0), 2 ) + norm( max(B*yopt3 - ubx, 0), 2 );
sol_diff3            = norm(yopt3 - y_cvx, 2)/nrmy_cvx;
time3                = toc(time3);

%% Call Chambolle-Pock algorithm.
options.Algorithm    = 'CP';
time4                = tic;
[optsol4, output4]   = QpAsgardSolver(Q, q, B, c, lbx, ubx, options, []);
yopt4                = optsol4.x_opt;
fx_val4              = 0.5*yopt4'*Q*yopt4 + q'*yopt4;
rel_feas4            = norm( min(B*yopt4 - lbx, 0), 2 ) + norm( max(B*yopt4 - ubx, 0), 2 );
sol_diff4            = norm(yopt4 - y_cvx, 2)/nrmy_cvx;
time4                = toc(time4);

%% Print the final results.
fprintf(['The objective values:       \n', ...
         '  +PAPA         = %3.20f\n  +PAPA-RS      = %3.20f\n', ...
         '  +PALPA        = %3.20f\n  +PALPA-RS     = %3.20f\n  +PAPA-SCVX    = %3.20f\n', ...
         '  +PAPA-SCVX-RS = %3.20f\n  +2L-ASGARD    = %3.20f\n  +1L-RS-ASGARD = %3.20f\n', ...
         '  +CP           = %3.20f\n  +CVX          = %3.20f\n'], ...
         fx_val1a, fx_val1b, fx_val1c, fx_val1d, fx_val1e, fx_val1f, ...
         fx_val2, fx_val3, fx_val4, fx_cvx);
fprintf(['The feasibilty violation:   \n', ...
         '  +PAPA         = %3.20f\n  +PAPA-RS      = %3.20f\n', ...
         '  +PALPA        = %3.20f\n  +PALPA-RS     = %3.20f\n  +PAPA-SCVX    = %3.20f\n', ...
         '  +PAPA-SCVX-RS = %3.20f\n  +2L-ASGARD    = %3.20f\n  +1L-RS-ASGARD = %3.20f\n', ...
         '  +CP           = %3.20f\n   +CVX         = %3.20f\n'], ...
         rel_feas1a, rel_feas1b, rel_feas1c, rel_feas1d, rel_feas1e, ...
         rel_feas1f, rel_feas2, rel_feas3, rel_feas4, rel_feas_cvx);
fprintf(['The solution differences:\n', ...
         '  +PAPA         = %3.20f\n  +PAPA-RS      = %3.20f\n', ...
         '  +PALPA        = %3.20f\n  +PALPA-RS     = %3.20f\n  +PAPA-SCVX    = %3.20f\n', ...
         '  +PAPA-SCVX-RS = %3.20f\n  +2L-ASGARD    = %3.20f\n  +1L-RS-ASGARD = %3.20f\n', ...
         '  +CP          = %3.20f\n'], ...
         sol_diff1a, sol_diff1b, sol_diff1c, sol_diff1d, sol_diff1e, ...
         sol_diff1f, sol_diff2, sol_diff3, sol_diff4);
fprintf(['The solution time in second:\n', ...
         '  +PAPA         = %3.20f\n  +PAPA-RS      = %3.20f\n', ...
         '  +PALPA        = %3.20f\n  +PALPA-RS     = %3.20f\n  +PAPA-SCVX    = %3.20f\n', ...
         '  +PAPA-SCVX-RS = %3.20f\n  +2L-ASGARD    = %3.20f\n  +1L-RS-ASGARD = %3.20f\n', ...
         '  +CP           = %3.20f\n  +CVX          = %3.20f\n'], ...
         time1a, time1b, time1c, time1d, time1e, time1f, time2, ...
         time3, time4, time_cvx);
     
% Plot the outputs.
fx_min = fx_cvx;
styles = {'-', '--', '-.', ':'};
colors = {'m', 'r', 'b', 'g', 'k'};
myplot = @(x) semilogy(x, 'MarkerSize', 3, 'Color', colors{randi(length(colors))}, 'LineWidth', 2, 'LineStyle', styles{randi(4)});

figure(1);
title('The objective residual');
myplot(abs(output1a.hist.fx_val - fx_min)/max(1, abs(fx_min))); hold on;
myplot(abs(output1b.hist.fx_val - fx_min)/max(1, abs(fx_min))); hold on;
myplot(abs(output1c.hist.fx_val - fx_min)/max(1, abs(fx_min))); hold on;
myplot(abs(output1d.hist.fx_val - fx_min)/max(1, abs(fx_min))); hold on;
myplot(abs(output1e.hist.fx_val - fx_min)/max(1, abs(fx_min))); hold on;
myplot(abs(output1f.hist.fx_val - fx_min)/max(1, abs(fx_min))); hold on;
myplot(abs(output2.hist.fx_val  - fx_min)/max(1, abs(fx_min))); hold on;
myplot(abs(output3.hist.fx_val  - fx_min)/max(1, abs(fx_min))); hold on;
myplot(abs(output4.hist.fx_val  - fx_min)/max(1, abs(fx_min))); hold on;
legend('PAPA', 'PAPA-RS', 'PALPA', 'PALPA-RS', 'PAPA-cvx', 'PAPA-cvx-rs', '2L-ASGARD', '1LR-ASGARD', 'CP');

figure(2);
title('The feasibility violation');
myplot(output1a.hist.rel_pfeas); hold on; 
myplot(output1b.hist.rel_pfeas); hold on; 
myplot(output1c.hist.rel_pfeas); hold on; 
myplot(output1d.hist.rel_pfeas); hold on; 
myplot(output1e.hist.rel_pfeas); hold on; 
myplot(output1f.hist.rel_pfeas); hold on; 
myplot(output2.hist.rel_pfeas);  hold on; 
myplot(output3.hist.rel_pfeas);  hold on; 
myplot(output4.hist.rel_pfeas);  hold on; 
legend('PAPA', 'PAPA-RS', 'PALPA', 'PALPA-RS', 'PAPA-cvx', 'PAPA-cvx-rs', '2L-ASGARD', '1LR-ASGARD', 'CP');

% End of the example.