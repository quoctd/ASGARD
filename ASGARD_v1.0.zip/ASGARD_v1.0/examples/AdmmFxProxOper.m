function xout = AdmmFxProxOper3(x, p, rho, mode)
    
    x1 = x(1:p,1); x2 = x(p+1:2*p,1); x3 = x(2*p+1:end,1);
    
    if mode == 1 % Jacobi mode.
        s1 = x2 + x3;
        
    else
        
    end
        
end