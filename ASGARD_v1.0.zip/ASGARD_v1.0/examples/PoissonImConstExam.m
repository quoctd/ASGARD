
X_org    = double(imread('confocal-stack-red.bmp'));
%X_org    = randi([0, 255], 16, 16);

%Create blurred and noisy version of the image
peak     = 30;
Xs       = X_org/max(X_org(:))*peak; 
h        = fspecial('gaussian',[9 9],4);
Xb       = imfilter(Xs, h,'conv','circular');
Yf       = poissrnd(Xb);  %Poisson noise. 

%lambda   = 0.055; %0.055; % Regularization parameter
lambda   = 0.055; % Regularization parameter

L_oper   = @(x)(imfilter(x, h, 'conv', 'circular'));
LT_oper  = @(x)(imfilter(x, h, 'conv', 'circular'));
[px, py] = size(Yf);

% Generate a starting point.
Lx       = L_oper(Xs);
Lty      = LT_oper(Yf);
xtmp     = sum(sum((LT_oper(ones(size(Yf))))));
X0       = (sum(sum(Yf)).*numel(Lty))./(sum(sum(Lty)) .* xtmp).*Lty;
X0       = X0(:);

% Generate inputs.
inputs.px     = px;
inputs.py     = py;
inputs.mx     = prod(size(Lx));
inputs.Loper  = L_oper;
inputs.LToper = LT_oper;
inputs.lambda = lambda;
inputs.Yf     = Yf;

% Call the ASGARD solver
options          = ASGARD_OptimSet([]);
options.MaxIters = 5000;
%options.isRestart = 1;
[optsol, output] = PoissonReconstAlg2(inputs, X0, options);
Xsol             = reshape(optsol.x_opt(1:px*py,1), px, py);

%% Plot the images.
figure(100);
imshow(Xs, []);
title('Ground-truth','fontsize',16);
figure(101);
imshow(Yf, []);
title('Blurred and noisy image','fontsize',16);
figure(103); imshow(Xsol, []);
title('Our restored image','fontsize',16);
