% The problem is
%                   min  g(x) + r(y)
%                   s.t. B*y - x = 0.
% where g(x) = lambda*|x|_1 and r(y) = 0.5*|A*y - b|^2.              

% data_opt                = 2;
% imaddress               = 'galaxy.jpg'; % optional, only required if 4 is chosen above
% small_data_size         = 16; % optional, only required if 3 is chosen above
% 
% [x_original, ind, m, n] = get_dataset(data_opt, small_data_size, imaddress);                                
% x_original              = imresize(x_original, [n, n]);

%file_name               = 'MRI_of_Knee';
%file_name               = 'MRI_brain_tumor2';
file_name               = 'im1_MRI_hip';
data_opt                = 4;
imaddress               = [file_name, '.jpg']; %
small_data_size         = [16, 16]; % optional, only required if 3 is chosen above
nresize                 = [64, 64];
[x_original, ind, m, n] = get_dataset(data_opt, small_data_size, imaddress, nresize);                                
x_original              = real(x_original);
 
%% Define the regularization parameter.
lambda                = 6e-4; % Default: 6.0e-4;

%% Set the optional parameters.
options                = ASGARD_OptimSet([]);
options.PrintStep      = 10;
options.saveHistMode   = 4;
options.isStoppingCond = 0;
options.MaxIters       = 200;
options.nRestart       = 100;
options.PwMaxIters     = 30;

% Define the A=subsampled fourier and D=difference operators
Aoper                 = @(X) fft2fwd(X, ind, m, n);
AToper                = @(X) fft2adj_rectangular_new(X, ind, m, n);
Boper                 = @(X) gradOperator( X );
BToper                = @(X) divOperator( X, n );

% The observed data and regularization parameter.
sigma                 = 0*1e-3;
cb                    = Aoper(x_original + sigma*randn(size(x_original)) );
fx_min                = 0.5*norm( Aoper(x_original) - cb, 'fro').^2 + lambda*norm(vec(Boper(x_original)), 1);

% Define an initial input.
Y0                    = zeros(size(x_original));
X0                    = Boper(Y0);

% Compute the Lipschitz constant of ry and the norm of B.
%LipsR                 = ASGARD_l2NormEval2( size(x_original), Aoper, ...
%                       AToper, options.PwMaxIters, options.PwRelTol);
LipsR                 = 1.0;
%LB_bar                = ASGARD_l2NormEval2( size(Y0), Boper, BToper, ...
%                       options.PwMaxIters, options.PwRelTol);
LB_bar                = 8.0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                            CALL SOLVERS                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%**************************************************************************
%% Define the objective function and its proximal operators.
%**************************************************************************
px                    = size(X0);
py                    = size(Y0);
objFunc.px            = px;
objFunc.py            = py;
objFunc.nc            = px;

soft_threshold_oper   = @(X, gamma) sign(X).*max(abs(X) - gamma, 0);
objFunc.gxProxOper    = @(X, gamma, varargin) ( soft_threshold_oper(X, lambda*gamma) );
objFunc.hyProxOper    = @(Y, gamma, varargin) ( Y );
objFunc.ryGradOper    = @(Y, varargin) ( AToper(Aoper(Y) - cb) );

objFunc.gxFunc        = @(X, varargin) ( lambda*norm(X(:), 1) );
objFunc.hyFunc        = @(Y, varargin) ( 0 );
objFunc.ryFunc        = @(Y, varargin) ( 0.5*norm( Aoper(Y) - cb, 'fro').^2 );
objFunc.ryLips        = LipsR;

linConstr.Aoper       = @(X, varargin) ( -X );
linConstr.AToper      = @(X, varargin) ( -X );
linConstr.Boper       = @(Y, varargin) ( Boper( Y ) );
linConstr.BToper      = @(Y, varargin) ( BToper(Y) );
linConstr.dlStarProx  = @(U, gamma, varargin) ( U );
linConstr.dlStarFunc  = @(U, varargin) ( norm(U, 'fro') );

% User define function to compute the objective value.
objFunc.usDefFunc     = @(X, Y, varargin) 0.5*norm( Aoper(Y) - cb, 'fro').^2 + lambda*norm(vec(Boper(Y)), 1);

% Set other parameters.
LA_bar                = 1;
linConstr.LA_bar      = LA_bar;
linConstr.LB_bar      = LB_bar;

%% Define the parameters for PAPA.
muhy                   = 5.0e-1;
beta1                  = 2.0*sqrt(LB_bar);

%**************************************************************************
%% Call our PAPA solver - non-strong convexity and no-restart.
%**************************************************************************
n_count = 0;
list_beta1 = linspace(0.001, 10, 100);
for ii=1:length(list_beta1)
    beta1                  = list_beta1(ii);
    options.Algorithm      = 'PAPA';
    options.isRestart      = 0;

    linConstr.beta1        = beta1;
    time1                  = tic;
    [optsol1, output1]     = nscvxPapa3Solver(objFunc, linConstr, X0, Y0, options);
    time1                  = toc(time1);
    % Get the output.
    Xopt1                  = abs(optsol1.y_opt);
    fx_val1                = 0.5*norm( Aoper(Xopt1) - cb, 'fro').^2 + lambda*norm(vec(Boper(Xopt1)), 1);
    sol_diff1              = norm(x_original - Xopt1, 'fro')/norm(x_original, 'fro');
    psnr1                  = psnr(Xopt1, x_original);
    
    % Store the result.
    n_count  = n_count + 1;
    list_fx(n_count, 1)    = fx_val1;
    list_schg(n_count, 1)  = sol_diff1;
    list_psnr(n_count, 1)  = psnr1;
    list_muhy(n_count, :)  = muhy;
end

return;
%**************************************************************************
%% Call our PAPA solver - strong convexity and no-restart.
%**************************************************************************
n_count = 0;
list_mu = linspace(0.001, 10, 100);
for ii=1:length(list_mu)
    muhy                   = list_mu(ii);
    options.Algorithm      = 'PAPA-SCVX';
    options.isRestart      = 0;

    linConstr.beta1        = 2*LB_bar/muhy;
    time3                  = tic;
    [optsol3, output3]     = scvxPapa3Solver(objFunc, linConstr, X0, Y0, options);
    time3                  = toc(time3);
    % Get the output.
    Xopt3                  = abs(optsol3.y_opt);
    fx_val3                = 0.5*norm( Aoper(Xopt3) - cb, 'fro').^2 + lambda*norm(vec(Boper(Xopt3)), 1);
    sol_diff3              = norm(x_original - Xopt3, 'fro')/norm(x_original, 'fro');
    psnr3                  = psnr(Xopt3, x_original);
    
    % Store the result.
    n_count  = n_count + 1;
    list_fx(n_count, 1)    = fx_val3;
    list_schg(n_count, 1)  = sol_diff3;
    list_psnr(n_count, 1)  = psnr3;
    list_muhy(n_count, :)  = muhy;
end

return
%**************************************************************************
%% Call Vu-Condat's algorithm without tuning.
%**************************************************************************
objFunc2.nx           = size(Y0);
soft_threshold_oper   = @(X, gamma) sign(X).*max(abs(X) - gamma, 0);
objFunc2.gxProxOper   = @(X, gamma, varargin) ( soft_threshold_oper(X, lambda*gamma) );
objFunc2.hxProxOper   = @(X, gamma, varargin) ( X );
objFunc2.rxGradOper   = @(X, varargin) ( AToper(Aoper(X) - cb) );

objFunc2.gxFunc       = @(X, varargin) ( lambda*norm(X(:), 1) );
objFunc2.hxFunc       = @(X, varargin) ( 0 );
objFunc2.rxFunc       = @(X, varargin) ( 0.5*norm( Aoper(X) - cb, 'fro').^2 );
objFunc2.rxLips       = LipsR;

linOper2.Boper        = @(Y, varargin) ( Boper( Y ) );
linOper2.BToper       = @(Y, varargin) ( BToper(Y) );
% User define function to compute the objective value.
objFunc2.usDefFunc    = @(X, Y, varargin) 0.5*norm( Aoper(X) - cb, 'fro').^2 + lambda*norm(vec(Boper(X)), 1);

% Set other parameters.
linOper2.LB_bar       = LB_bar;

%**************************************************************************
%% Call Vu-Condat's algorithm with tuning.
%**************************************************************************
lb_tau   = 5e-2;
ub_tau   = 0.98*2/LipsR;
lb_sig   = 5e-2;
n_trys   = 50;
n_trys2  = 10;
list_tau = linspace(lb_tau, ub_tau, n_trys);
n_count  = 0;
for ii = 1:length(list_tau)
    param.tau             = list_tau(ii);
    %ub_sig                = (1/param.tau - 0.5*LipsR)/LB_bar;
    %list_sig              = linspace(lb_sig, ub_sig, n_trys2);
    %for jj = 1:length(list_sig)
        %param.sigma           = list_sig(jj);
        %ub_sig                = (1/param.tau - 0.5*LipsR)/LB_bar;
        param.sigma           = (1/param.tau - 0.5*LipsR)/LB_bar;
        
        param.theta           = 1.0;
        options.Algorithm     = 'VU-CONDAT';
        time6                 = tic;
        [optsol6, output6]    = nscvxVuCondatSolver(objFunc2, linOper2, Y0, options, param);
        time6                 = toc(time6);
        Xopt6                 = abs(optsol6.x_opt);
        fx_val6               = 0.5*norm( Aoper(Xopt6) - cb, 'fro').^2 + lambda*norm(vec(Boper(Xopt6)), 1);
        sol_diff6             = norm(x_original - Xopt6, 'fro')/norm(x_original, 'fro');
        psnr6                 = psnr(Xopt6, x_original);

        % Store the result.
        n_count  = n_count + 1;
        list_fx(n_count, 1)    = fx_val6;
        list_schg(n_count, 1)  = sol_diff6;
        list_psnr(n_count, 1)  = psnr6;
        list_param(n_count, :) = [param.tau, param.sigma];
    %end
end

%% Plot the figure.
figure(2);
colormap('gray');
subplot(3,3,1); imagesc(x_original); hold on; xlabel('Original');
subplot(3,3,2); imagesc(Xopt1); hold on; xlabel('PAPA');
subplot(3,3,4); imagesc(Xopt3); hold on; xlabel('scvx-PAPA');
subplot(3,3,7); imagesc(Xopt6); hold on; xlabel('Vu-Condat-adapt');

