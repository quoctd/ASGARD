%% Example: Quadratic program
%           min_x 1/2 x^T * Q * x - q^T * x
%            s.t. A*x <= b 
%

clear all

scale                       = 10;
p                           = scale * 10;
n                           = scale * 10;

Tmp                         = randn(n, p);
B                           = 0.5*(Tmp + Tmp');
[D, U]                      = eig(B);
dd                          = max(diag(D), 0) + 1e-2;
B                           = U*diag(dd)*U';
eig_values                  = eig(B);
mu                          = min(eig_values);

mb                          = round(n);
A                           = randn(n, p);
q                           = randn(n, 1);

s                           = round(p/2);
x_org                       = zeros(p, 1);
T                           = randsample(p, s);
x_org(T)                    = randn(s, 1);
sigma                       = 1e-0;
noise                       = rand(mb, 1);
cb                          = A*x_org + sigma*noise;

% Define problem.
objFunc.nx                  = p;
objFunc.fxProxOper          = @(x, lambda, varargin) inv(eye(n, p) + lambda * B)*(x + lambda * q );

objFunc.fxFunc              = @(x) 1/2 * x' * B * x - q' * x;
linConstr.Aoper             = @(x, varargin) A*x;
linConstr.AToper            = @(x, varargin) A'*x;
linConstr.cb                = cb;

proj_ineq_constr            = @(x, cb) min(x, cb);
linConstr.gyStarProx        = @(x, lambda) x - lambda * proj_ineq_constr(x/lambda, cb);
linConstr.gyStarFunc        = @(x, lambda) norm(max(x - cb, 0), 2);

% Generate a starting point.
x0                          = zeros(p, 1);


%% cvx solution
cvx_solver mosek;
cvx_precision best;
cvx_begin
    variable x(p);
    minimize( 1/2 * x' * B * x - q' * x );
    subject to
        A*x <= cb;
cvx_end

fopt1 = objFunc.fxFunc(x_org);
fopt = cvx_optval;
% fopt = min(fopt1, fopt);
%%
alpha                       = 1.2;
m_0                         = max(10, round(alpha/(alpha-1)) + 1);
outer_dl                    = 30;

K_dl_asgard                 = m_0 * (alpha^((outer_dl+1) / 2)-1)/(sqrt(alpha)-1);

options                     = ASGARD_OptimSet([]);
options.isStoppingCond      = false;
options.num_eps             = outer_dl;
options.MaxIters            = 1e4;

LA_bar                      = ASGARD_l2NormEval(objFunc.nx, linConstr.Aoper, linConstr.AToper, ...
                              options.PwMaxIters, options.PwRelTol);

options.LA_bar              = LA_bar;
options.constrained         = 1;

%% Two Loop Asgard
options_dl                  = options;
% options_dl.beta1               = alpha * LA_bar /(mu * m_0^2);
options_dl.beta1            = 1*sqrt(LA_bar);
options_dl.m_0              = m_0;
options_dl.alpha            = alpha;

[optsol_dl, output_dl]      = TwoLoopAsgardSolver(objFunc, linConstr, x0, options_dl);
options.MaxIters            = output_dl.total_iters;
%%
% options.mu              = mu;

% options.is_sc           = 1;
% 
% [optsol_dl_mu, output_dl_mu]  = copAsgardSolver_TwoLoop(objFunc, linConstr, x0, options_dl, B, q);
% toc
% 
% tic
% options.beta1           = 0.5*sqrt(LA_bar);
% options.is_sc           = 0;
% [optsol_dl, output_dl]  = copAsgardSolver_TwoLoop(objFunc, linConstr, x0, options);
% toc
%% One Loop Asgard
options_ol                  = options;
options_ol.isRestart        = 0;
options_ol.beta1            = 1*sqrt(LA_bar);

[optsol_ol, output_ol]      = copAsgardSolver(objFunc, linConstr, x0, options_ol);

%% One Loop Asgard restart
options_olr                 = options;
options_olr.isRestart       = 1;
options_olr.nRestart        = 25;
options_olr.beta1           = 1*sqrt(LA_bar);

[optsol_olr, output_olr]    = copAsgardSolver(objFunc, linConstr, x0, options_olr);

%% Olivier's Restarting Asgard
if 0
options_o                   = options;
options_o.alpha             = 4;
options_o.beta1             = options_o.alpha*LA_bar/mu;
% options_o.beta1             = 40*LA_bar;
% options_o.beta1             = 2*sqrt(LA_bar);
options_o.m_0               = 1;
options_o.mu                = mu;
options_o.num_eps           = 50;
options_o.limit             = 1e4;

[optsol_o, output_o]        = OlivierRestartAsgardSolver(objFunc, linConstr, x0, options_o);
figure, subplot(121), loglog(abs(output_o.hist.fx_val - fopt)/abs(fopt), 'g')
grid on
subplot(122), loglog(output_o.hist.rel_pfeas, 'g')
grid on
optsol_o.x_opt
end
%%
% Plot the output results.
figure, subplot(121);
loglog(abs(output_dl.hist.fx_val - fopt)/abs(fopt), 'r'); xlabel('The objective value');
hold on
% semilogy(abs(output_dl_mu.hist.fx_val - fopt)/abs(fopt), 'g'); xlabel('The objective value');
loglog(abs(output_ol.hist.fx_val - fopt)/abs(fopt), 'b');
loglog(abs(output_olr.hist.fx_val - fopt)/abs(fopt), 'k')


% semilogy(1 ./counter)
% semilogy(1 ./(counter.^2))
% legend('double loop asgard', 'double loop asgard with s.c. constant', 'one loop asgard', 'one loop asgard-restart')
legend('double loop asgard', 'one loop asgard', 'one loop asgard-restart', 'oliviers restart')

subplot(122);
loglog(output_dl.hist.rel_pfeas, 'r'); xlabel('The feasibility');
hold on
% semilogy(output_dl_mu.hist.rel_pfeas, 'g')
loglog(output_ol.hist.rel_pfeas, 'b')
loglog(output_olr.hist.rel_pfeas, 'k')

legend('double loop asgard', 'double loop asgard with s.c. constant', 'one loop asgard', 'one loop asgard-restart')
legend('double loop asgard', 'one loop asgard', 'one loop asgard-restart', 'oliviers restart')

% figure(3);
% stairs(x, 'b--'); hold on; stairs(optsol.x_opt, 'r-.');

% fprintf('The objective values: Our-DL = %3.6f, Our-DL-mu = %3.6f, Our-OL = %3.6f, Our-OL-r = %3.6f, CVX = %3.6f\n', optsol_dl.fx_val, optsol_dl_mu.fx_val, optsol_ol.fx_val, optsol_ol_r.fx_val, fopt);












