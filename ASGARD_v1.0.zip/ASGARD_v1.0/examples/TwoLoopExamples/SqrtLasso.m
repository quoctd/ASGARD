clear all
close all


scale           = 20;
p               = scale*100;
n               = scale*30; 
s               = scale*10; 
p12             = round(p/2);
sigma           = 1e-3;
thresh          = @(x, r) sign(x).*max(abs(x) - r, 0);

% Generate matrix A.
A               = randn(n, p);

% Generate vector c.
x_org           = zeros(p, 1);
T               = randsample(n, s);
x_org(T)        = randn(s, 1);
noise           = thresh( randn(n, 1), 100);
cb              = A*x_org + sigma*noise;
reg             = 1e-1;

%%
objFunc.nx          = p;
objFunc.fxProxOper  = @(x, tau, varargin) ...
                      [sign(x(1:p12)).*max(abs(x(1:p12)) - reg* tau, 0); ...
                       sign(x(p12+1:end)).*max(abs(x(p12+1:end)) - reg* tau, 0)];
objFunc.fxFunc      = @(x, varargin) norm(A*x - cb, 2) + reg * norm(x,1);
linConstr.Aoper     = @(x, varargin) A*x;
linConstr.AToper    = @(x, varargin) A'*x;
linConstr.cb        = cb;
prox_l2             = @(ss, gamma) max(0.0, 1 - gamma/norm(ss,2)).*ss;

prox_l2_linear       = @(x, lambda) prox_l2(x - cb, lambda) + cb;
linConstr.gyStarProx = @(x, lambda) x - lambda * prox_l2_linear(x/lambda, 1/lambda);
linConstr.gyStarFunc = @(x, lambda) 0;

% Generate a starting point.
x0                 = zeros(p, 1);

%% cvx
cvx_solver mosek;
cvx_precision best;
cvx_begin
    variable x(p);
    minimize( norm(A*x - cb, 2) + reg * norm(x,1));
cvx_end
fopt = cvx_optval;

%% Define optional parameters.
alpha                       = 1.62;
m_0                         = max(10, round(alpha/(alpha-1)) + 1);
outer_dl                    = 30;

% K_dl_asgard                 = m_0 * (alpha^((outer_dl+1) / 2)-1)/(sqrt(alpha)-1);
K_dl_asgard                 = (m_0+2) * (alpha^outer_dl - 1)/(alpha-1);

options                     = ASGARD_OptimSet([]);
options.isStoppingCond      = false;
options.num_eps             = outer_dl;
options.MaxIters            = 2000;

LA_bar                      = ASGARD_l2NormEval(p, linConstr.Aoper, linConstr.AToper, ...
                              options.PwMaxIters, options.PwRelTol);
options.LA_bar              = LA_bar;
options.reg                 = reg;
options.constrained         = 0;

%% Two Loop Asgard solver
options_dl                  = options;

options_dl.m_0              = m_0;
options_dl.alpha            = alpha;
options_dl.beta1            = 3*sqrt(LA_bar);

[optsol_dl, output_dl]      = TwoLoopAsgardSolver(objFunc, linConstr, x0, options_dl);
% figure, loglog(abs(output_dl.hist.fx_val - fopt)/fopt, 'r'); xlabel('The objective value');
options.MaxIters                 = output_dl.total_iters;
% output_dl.final_beta
%
%
% fopt1 = norm(A*x_org - cb, 2) + reg*norm(x_org,1);
% fopt  = min(fopt, fopt1);
% figure, loglog(abs(output_dl.hist.fx_val - fopt)/fopt, 'r'); xlabel('The objective value');
% hold on,loglog(abs(output_ol.hist.fx_val - fopt)/fopt, 'b'); xlabel('The objective value');
% loglog(abs(output_olr.hist.fx_val - fopt)/fopt, 'k'); xlabel('The objective value');
% legend('two loop', 'one loop', 'one loop restart')
% norm(optsol_dl.x_opt - x, 2)
% norm(optsol_olr.x_opt - x, 2)
%% One Loop Asgard
options_ol                  = options;
options_ol.isRestart        = 0;
options_ol.beta1            = .5*sqrt(LA_bar);
[optsol_ol, output_ol]      = copAsgardSolver(objFunc, linConstr, x0, options_ol);

%% One Loop Asgard restart
options_olr                 = options;
options_olr.isRestart       = 1;
options_olr.nRestart        = 10;
options_olr.beta1           = 3*sqrt(LA_bar);
objFunc.cgyProxOper         = linConstr.gyStarProx;
linConstr.mx                = n;
[optsol_olr, output_olr]    = uopAsgardSolver(objFunc, linConstr, x0, options_olr);

%% One Loop asgard restart
if 0
objFunc.cgyProxOper         = linConstr.prox_g_star;
linConstr.mx                  = n;
options_u                 = options;
% options_u.MaxIters          = 1e4;
options_u.isRestart       = 0;
options_u.nRestart        = 25;
options_u.beta1           = 5*sqrt(LA_bar);

[optsol_u, output_u]        = TsengUopAsgardSolver(objFunc, linConstr, x0, options_u);
% figure, loglog(abs(output_u.hist.fx_val - fopt)/fopt)
% hold on
% loglog(abs(output_ol.hist.fx_val - fopt)/fopt)
end
%%
fopt1 = norm(A*x_org - cb, 2) + reg*norm(x_org,1);
fopt  = min(fopt, fopt1);
figure, loglog(abs(output_dl.hist.fx_val - fopt)/fopt, 'r'); xlabel('The objective value');
hold on,loglog(abs(output_ol.hist.fx_val - fopt)/fopt, 'b'); xlabel('The objective value');
loglog(abs(output_olr.hist.fx_val - fopt)/fopt, 'k'); xlabel('The objective value');
% loglog(abs(output_u.hist.fx_val - fopt)/fopt)
legend('two loop', 'one loop', 'one loop restart')
norm(optsol_dl.x_opt - x, 2)
norm(optsol_olr.x_opt - x, 2)

