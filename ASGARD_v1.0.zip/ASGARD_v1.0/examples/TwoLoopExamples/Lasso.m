%% Example: 1/2 ||Fu-c||^2 + lambda ||u||_1
%
%           We formulate the problem as
%           min_x 1/2 ||z||^2 + lambda ||u||_1
%           s.t.        Ax = b
%                       where A = [F, -I], x = [u; z], b=c

clear all

scale                       = 10;
% p                           = scale*100;
% n                           = scale*35; 
p                           = scale*100;
n                           = scale*30; 
s                           = scale*10; 
p12                         = round(p/2);
sigma                       = 0*1e-3;
thresh                      = @(x, r) sign(x).*max(abs(x) - r, 0);
reg                         = 1;
% Generate matrix A.
A                           = randn(n, p);
mu                          = min(eigs(A'*A));
% Generate vector c.
x_org                       = zeros(p, 1);
T                           = randsample(p, s);
x_org(T)                    = randn(s, 1);
noise                       = thresh( randn(n, 1), 100);
cb                          = A*x_org + sigma*noise;



%% Cvx solution.
cvx_solver mosek;
cvx_precision best;
cvx_begin
    variable x_cvx(p);
    minimize( 1/2 * square_pos(norm(A*x_cvx - cb, 2)) + reg * norm(x_cvx, 1) );
cvx_end
fopt = cvx_optval;


%% 
% Define problem.
z0                          = zeros(n, 1);
u0                          = zeros(p, 1);
A_s                         = [A, -eye(n, n)];
x0                          = [u0; z0]; % n+p dim.

objFunc.nx                  = p;
objFunc.fxProxOper          = @(x, tau, varargin) [sign(x(1:p)).*max(abs(x(1:p)) - reg*tau, 0); x(p+1:end) / (1+tau)  ];
objFunc.fxFunc              = @(x) 1/2 * norm(x(p+1:end), 2)^2 + reg*norm(x(1:p),1);
linConstr.Aoper             = @(x, varargin) A_s*x;
linConstr.AToper            = @(x, varargin) A_s'*x;
linConstr.cb                = cb;
linConstr.gyStarProx        = @(x, lambda) x - lambda * cb;
linConstr.gyStarFunc        = @(x, lambda) 0;

%% parameters
alpha                       = 1.2;          % changing factor for beta and m_l
m_0                         = max(10, round(alpha/(alpha-1)) + 1); % starting point for inner iteration counts
outer_dl                    = 40;           % desired number of outer iterations

K_dl_asgard                 = m_0 * (alpha^((outer_dl+1) / 2)-1)/(sqrt(alpha)-1);  
                                            % total number of iterations
                                            % according to desired number of iterations%% Two Loop Asgard solver

options                     = ASGARD_OptimSet([]);
options.isStoppingCond      = false;
options.num_eps             = outer_dl;     % number of outer iterations
options.MaxIters            = 3000;  % total number of iterations for both alg.

LA_bar                      = ASGARD_l2NormEval(length(x0), linConstr.Aoper, linConstr.AToper, ...
                            options.PwMaxIters, options.PwRelTol);

options.LA_bar              = LA_bar;
options.constrained         = 1;

%% Two Loop Asgard solver
options_dl                  = options;
options_dl.beta1            = sqrt(LA_bar);
options_dl.m_0              = m_0;
options_dl.alpha            = alpha;
[optsol_dl, output_dl]      = TwoLoopAsgardSolver(objFunc, linConstr, x0, options_dl);


%% one loop asgard restart
options_ol                  = options;
options_ol.isRestart        = 1;
options.nRestart            = 25;
options_ol.beta1            = sqrt(LA_bar);

[optsol_ol, output_ol]      = copAsgardSolver(objFunc, linConstr, x0, options_ol);

%%

figure, subplot(121);
loglog(abs(output_dl.hist.fx_val - fopt)/fopt, 'r'); xlabel('The objective value');
hold on,
loglog(abs(output_ol.hist.fx_val - fopt)/fopt, 'b'); xlabel('The objective value');
legend('two loop', 'restart')
subplot(122)
loglog(output_dl.hist.rel_pfeas, 'r'); xlabel('The feasibility');
hold on
loglog(output_ol.hist.rel_pfeas, 'b')

legend('two loop', 'restart')

%%
if 0
    objFunc.cgyProxOper       = linConstr.prox_g_star;
    linConstr.mx                  = n;
    options_u                 = options;
    % options_u.MaxIters          = 1e4;
    options_u.isRestart       = 0;
    options_u.nRestart        = 25;
    options_u.beta1           = sqrt(LA_bar);

    [optsol_u, output_u]      = TsengUopAsgardSolver(objFunc, linConstr, x0, options_u);

    % figure, subplot(121); loglog(abs(output_u.hist.fx_val - fopt)/fopt);
    % hold on,
    % loglog(output_u.hist.rel_pfeas)
end
%%
if 0
    options_o                   = options;
    options_o.alpha             = 4;
    options_o.beta1             = options_o.alpha*LA_bar/mu;
    % options_o.beta1             = 40*LA_bar;
    % options_o.beta1             = 2*sqrt(LA_bar);
    % options_o.alpha             = 4;
    options_o.m_0               = 1;
    options_o.mu                = mu;
    options_o.num_eps           = 50;
    options_o.limit             = 1e4;

    [optsol_o, output_o]        = OlivierRestartAsgardSolver(objFunc, linConstr, x0, options_o);
    figure, loglog(abs(output_o.hist.fx_val - fopt)/abs(fopt), 'g')
end

