%% EXAMPLE 1: A simple basis pursuit: 
%             min_x |x|_1 s.t. A*x = b.
%
%  Created by Quoc Tran-Dinh, STAT-OR, UNC-Chapel Hill, NC, USA.
%  Date: 08.28.2016. 

% Problem size.
clear all


scale                       = 20;
p                           = scale*100;
n                           = scale*35; 
s                           = scale*10; 
p12                         = round(p/2);
sigma                       = 1e-1;
thresh                      = @(x, r) sign(x).*max(abs(x) - r, 0);

% Generate matrix A.
A                           = randn(n, p);

% Generate vector c.
x_org                       = zeros(p, 1);
T                           = randsample(n, s);
x_org(T)                    = randn(s, 1);
noise                       = thresh( randn(n, 1), 100);
cb                          = A*x_org + sigma*noise;

% Define problem.
objFunc.nx                  = p;
objFunc.fxProxOper          = @(x, tau, varargin) ...
                            [sign(x(1:p12)).*max(abs(x(1:p12)) - tau, 0); ...
                            sign(x(p12+1:end)).*max(abs(x(p12+1:end)) - tau, 0)];
objFunc.fxFunc              = @(x) norm(x, 1);
linConstr.Aoper             = @(x, varargin) A*x;
linConstr.AToper            = @(x, varargin) A'*x;
linConstr.cb                = cb;
linConstr.gyStarProx        = @(x, lambda) x - lambda * cb;
linConstr.gyStarFunc        = @(x, lambda) norm(x - cb);

% Generate a starting point.
x0                          = zeros(p, 1);

%% Cvx solution.
cvx_solver mosek;
cvx_precision best;
cvx_begin
    variable x_cvx(p);
    minimize( norm(x_cvx, 1) );
    subject to
        A*x_cvx == cb;
cvx_end
fopt = cvx_optval;


%% Define generic parameters for all algorithms.
alpha                       = 1.05;          % changing factor for beta and m_l
m_0                         = max(10, round(alpha/(alpha-1)) + 1);  % starting point for inner iteration counts
outer_dl                    = 100;           % desired number of outer iterations

K_dl_asgard                 = m_0 * (alpha^((outer_dl+1) / 2)-1)/(sqrt(alpha)-1);  
                                            % total number of iterations
                                            % according to desired number of iterations%% Two Loop Asgard solver

options                     = ASGARD_OptimSet([]);
options.isStoppingCond      = false;
options.num_eps             = outer_dl;     % number of outer iterations
options.MaxIters            = 2e3;  % total number of iterations for both alg.

LA_bar                      = ASGARD_l2NormEval(p, linConstr.Aoper, linConstr.AToper, ...
                            options.PwMaxIters, options.PwRelTol);

options.LA_bar              = LA_bar;
options.constrained         = 1;
                                                                   
%% Two Loop Asgard solver

options_dl                  = options;
options_dl.beta1            = sqrt(LA_bar);
options_dl.m_0              = m_0;
options_dl.alpha            = alpha;

[optsol_dl, output_dl]      = TwoLoopAsgardSolver(objFunc, linConstr, x0, options_dl);
options.MaxIters                 = output_dl.total_iters;
% figure , loglog(abs(output_dl.hist.fx_val - fopt)/fopt, 'r'); xlabel('The objective value');
%% One Loop Asgard solver

options_ol                  = options;
options_ol.isRestart        = 0;
options_ol.beta1            = sqrt(LA_bar);

[optsol_ol, output_ol]      = copAsgardSolver(objFunc, linConstr, x0, options_ol);


%% One Loop Asgard with Restart solver
options_olr                 = options;
options_olr.isRestart       = 1;
options_olr.nRestart        = 25;
options_olr.beta1           = sqrt(LA_bar);
% options_olr.MaxIters        = optsol_dl.numiter;
[optsol_olr, output_olr]    = copAsgardSolver(objFunc, linConstr, x0, options_olr);


% figure, subplot(121);
% semilogy(abs(output_dl.hist.fx_val - fopt)/fopt, 'r');
% hold on, semilogy(abs(output_olr.hist.fx_val - fopt)/fopt, 'k')
%% Chambolle Pock Solver

options_cp                  = options;
[optsol_cp, output_cp]      = ChambollePockSolver(objFunc, linConstr, x0, options_cp);

%% Plot the output results.
% fopt = min([output_dl.hist.fx_val(end), output_ol.hist.fx_val(end), output_olr.hist.fx_val(end), output_cp.hist.fx_val(end)]);

figure, subplot(121);
loglog(abs(output_dl.hist.fx_val - fopt)/fopt, 'r'); xlabel('The objective value');
hold on
loglog(abs(output_ol.hist.fx_val - fopt)/fopt, 'b')
loglog(abs(output_olr.hist.fx_val - fopt)/fopt, 'k')
loglog(abs(output_cp.hist.fx_val - fopt)/fopt, 'm')
legend('double loop', 'asgard', 'asgard-restart', 'chambolle pock')
grid on
subplot(122);
loglog(output_dl.hist.rel_pfeas, 'r'); xlabel('The feasibility');
hold on
loglog(output_ol.hist.rel_pfeas, 'b')
loglog(output_olr.hist.rel_pfeas, 'k')
loglog(output_cp.hist.rel_pfeas, 'm')
legend('double loop', 'asgard', 'asgard-restart', 'chambolle pock')
grid on

% figure(3);
% stairs(x, 'b--'); hold on; stairs(optsol.x_opt, 'r-.');

% fprintf('The objective values: Our = %3.6f, CVX = %3.6f\n', optsol.fx_val, fopt);

