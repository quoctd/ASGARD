%% Example: Deblurring
%           min_x lambda * || Ax - b ||_2 ^2 + ||x||_TV
%           
%           
%

clear all
close all
%
n                   = 16;
p                   = 16;
% x_org               = phantom(n, p);

I                   = imread('mri.tif');
x_org               = double(I);
x_org               = imresize(x_org, [n, p]);

sigma               = 1e-2;
kernel              = fspecial('gaussian', 3,2);
% % b                   = imfilter(x_org, kernel, 'circular', 'conv') ;%+ sigma * randn(n, p);
% b                   = imfilter(x_org, kernel, 'conv', 'symmetric');
% Atb                 = imfilter(b, kernel, 'conv', 'symmetric');
% % Atb                 = imfilter(b, kernel, 'circular', 'corr');
% 
% 
% figure, subplot(131), imshow(x_org, [])
% subplot(132), imshow(b, [])
% subplot(133), imshow(Atb, [])

reg                 = 1;
D1d                 = gradOperator1d(eye(n, p));


% blurOper            = @(x) vec(imfilter(reshape(x, [n, p]), kernel, 'conv', 'symmetric'));
% blurTrOper          = @(x) vec(imfilter(reshape(x, [n, p]), kernel, 'corr', 'symmetric'));
[P,center]  = psfGauss([n,p], 4);

Pbig    = padPSF(P, [n,p]);
        e_vec1       = zeros(n,p);
        e_vec1(1, 1) = 1;
        eigs_blur          = dct2(dctshift(Pbig,center))./dct2(e_vec1);
%                 eigs_blur     = fft2(circshift(Pbig, 1 - center));

blurOper            = @(x, eigs_blur) idct2(eigs_blur.*dct2(x));
blurTrOper          = @(x, eigs_blur) idct2(conj(eigs_blur) .* dct2(x));
% blurOper  = @(x, eigs_blur) sqrt(p*n)*ifft2((1/sqrt(n*p)*fft2(x).*eigs_blur));
% blurTrOper = @(x, eigs_blur) 1/sqrt(n*p)*fft2((sqrt(p*n)*ifft2(x)./eigs_blur));
        
        % computng the eigenvalues of the blurring matrix         

% blurOper2            = @(x) (imfilter((x), kernel, 'conv', 'symmetric'));
% blurTrOper2          = @(x) (imfilter((x), kernel, 'corr', 'symmetric'));
%% cvx
blurOperMat         = blurOper(eye(n,p), eigs_blur);
blurTrOperMat         = blurTrOper(eye(n,p), eigs_blur);
% blurOperMat         = blurOper2(eye(n,p));
% blurTrOperMat         = blurTrOper2(eye(n,p));

b=blurOperMat*x_org + sigma * randn(n, p);

cvx_precision best;
cvx_begin
    variable x(n,p);
    minimize( 1/2 * square_pos(norm(vec(blurOperMat*x) - vec(b), 2)) + reg * norm([vec(D1d*x); vec(D1d*x')],1));
cvx_end
fopt = cvx_optval;

% figure, subplot(121), imshow(h, []), subplot(122), imshow(x, [])

%%
soft_thresh                 = @(x, r) sign(x).*max(abs(x) - r, 0);

cb                          = vec(b);
objFunc.nx                  = p*n;

% objFunc.fxProxOper = @(x, tau, varargin) ...
%                       lambda*[sign(x(1:p12)).*max(abs(x(1:p12)) - tau, 0); ...
%                        sign(x(p12+1:end)).*max(abs(x(p12+1:end)) - tau, 0)];
% objFunc.fxProxOper = @(x, tau, varargin) thresh(x, tau);

objFunc.fxFunc              = @(x, varargin) 1/2 * norm(vec(blurOperMat*(reshape(x, [n, p]))) - cb, 2)^2 + reg * norm(gradOperator(x),1);
linConstr.Aoper             = @(x, varargin) gradOperator(x);
linConstr.AToper            = @(x, varargin) divOperator(x);
linConstr.cb                = cb;

% prox_l2                     = @(ss, gamma) max(0.0, 1 - gamma/norm(ss,2)).*ss;
% objFunc.fxProxOper          = @(x, lambda) prox_l2(x - cb, lambda*reg) + cb; % linear function inside l2 norm
objFunc.fxProxOper          = @(x, lambda)  vec(inv(lambda *(blurTrOperMat * blurOperMat) + eye(n,p)) * reshape((x + lambda * vec(blurTrOperMat*(reshape(cb, [n, p])))), [n,p]) );
% objFunc.fxProxOper          = @(x, lambda)   (x + lambda * vec(blurTrOperMat*(reshape(cb, [n, p]))))/(1 + lambda);

linConstr.prox_g_star       = @(x, lambda) x - lambda*soft_thresh(x/lambda, reg/lambda);

% Generate a starting point.
x0                          = zeros(n*p, 1);

%%
m_0                         = 15;
alpha                       = 1.2;
outer_dl                    = 20;

K_dl_asgard                 = m_0 * (alpha^((outer_dl+1) / 2)-1)/(sqrt(alpha)-1);


options                     = ASGARD_OptimSet([]);
options.isStoppingCond      = false;
options.num_eps             = outer_dl;
options.MaxIters            = K_dl_asgard;
options.reg                 = reg;
LA_bar                      = ASGARD_l2NormEval(p, linConstr.Aoper, linConstr.AToper, ...
                              options.PwMaxIters, options.PwRelTol);

options.LA_bar              = LA_bar;
options.constrained         = 0;

%% Two Loop Asgard
options_dl                  = options;
options_dl.beta1            = .8*sqrt(LA_bar);
options_dl.m_0              = m_0;
options_dl.alpha            = alpha;

[optsol_dl, output_dl]      = TwoLoopAsgardSolver(objFunc, linConstr, x0, options_dl);
options.MaxIters                 = output_dl.total_iters;
%  figure, 
% loglog((output_dl.hist.fx_val-fopt)./fopt, 'r'), 

%% One Loop Asgard
options_ol                  = options;
options_ol.isRestart        = 0;
options_ol.beta1            = 1e5*sqrt(LA_bar);

[optsol_ol, output_ol]      = copAsgardSolver(objFunc, linConstr, x0, options_ol);


%% One Loop Asgard with restart
options_olr                 = options;
options_olr.isRestart       = 1;
options_olr.nRestart        = 25;
options_olr.beta1           = 15*sqrt(LA_bar);
% options_olr.MaxIters                 = 1e4;

[optsol_olr, output_olr]    = copAsgardSolver(objFunc, linConstr, x0, options_olr);
% figure, loglog(abs(output_olr.hist.fx_val-fopt)./fopt, 'k')


%%
figure, 
loglog(abs(output_dl.hist.fx_val-fopt)./fopt, 'r'), 
hold on, 
loglog(abs(output_ol.hist.fx_val-fopt)./fopt, 'b')
loglog(abs(output_olr.hist.fx_val-fopt)./fopt, 'k')
legend('two loop', 'one loop', 'one loop restart')



%% hops
if 0
options_hops                = options;
D                           = 1;
options_hops.alpha          = 10; 
options_hops.num_eps        = 10;
options_hops.beta1          = (objFunc.fxFunc(x0)-fopt) / (options_hops.alpha*D^2);
options_hops.m_l            = 200;
[optsol_hops, output_hops]  = HOPS_like(objFunc, linConstr, x0, options_hops);

figure,
loglog((output_hops.hist.fx_val-fopt)./fopt), 
hold on, 
loglog((output_dl.hist.fx_val-fopt)./fopt, 'r'), 
end


