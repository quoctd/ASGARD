%% EXAMPLE 1: A simple basis pursuit: 
%             min_x |x|_1 s.t. A*x = b.
%
%  Created by Quoc Tran-Dinh, STAT-OR, UNC-Chapel Hill, NC, USA.
%  Date: 08.28.2016. 

% Problem size.
clear all


scale    = 1;
p        = scale*100;
n        = scale*35; 
s        = scale*10; 
p12      = round(p/2);
sigma    = 1e-1;
thresh   = @(x, r) sign(x).*max(abs(x) - r, 0);

% Generate matrix A.
A        = randn(n, p);

% Generate vector c.
x_org    = zeros(p, 1);
T        = randsample(n, s);
x_org(T) = randn(s, 1);
noise    = thresh( randn(n, 1), 100);
cb       = A*x_org + sigma*noise;

% Define problem.
objFunc.nx         = p;
objFunc.fxProxOper = @(x, tau, varargin) ...
                      [sign(x(1:p12)).*max(abs(x(1:p12)) - tau, 0); ...
                       sign(x(p12+1:end)).*max(abs(x(p12+1:end)) - tau, 0)];
objFunc.fxFunc     = @(x, varargin) norm(x, 1);
linConstr.Aoper    = @(x, varargin) A*x;
linConstr.AToper   = @(x, varargin) A'*x;
linConstr.cb       = cb;
linConstr.prox     = @(x, lambda) x - lambda * cb;
% Generate a starting point.
x0                 = zeros(p, 1);

%% Define optional parameters.
m_0=10;
alpha = 1.3;
outer_dl_asgard = 25;

K_dl_asgard  = m_0 * (alpha^((outer_dl_asgard+1) / 2)-1)/(sqrt(alpha)-1);

options = ASGARD_OptimSet([]);

options.num_eps     = outer_dl_asgard;
options.MaxIters  = K_dl_asgard;

LA_bar     = ASGARD_l2NormEval(p, linConstr.Aoper, linConstr.AToper, ...
             options.PwMaxIters, options.PwRelTol);
options.LA_bar = LA_bar;
options.beta1           = 0.5*sqrt(LA_bar);
options.m_0             = m_0;
options.alpha           = alpha;
options.mu              = 0;
options.is_sc           = 0;
options.is_qp           = 0;
%% Call the solver.
tic
% options.MaxIters  = 100000;
options.isRestart = 0;
options.nRestart  = 25;
options.beta1           = .5*sqrt(LA_bar);
[optsol_dl, output_dl]  = copAsgardSolver_TwoLoop(objFunc, linConstr, x0, options);

options.beta1           = .5*sqrt(LA_bar);
[optsol_ol, output_ol]  = copAsgardSolver(objFunc, linConstr, x0, options);


options.isRestart = 1;
options.nRestart  = 25;
[optsol_ol_r, output_ol_r]  = copAsgardSolver(objFunc, linConstr, x0, options);




toc
%% Cvx solution.
cvx_precision best;
cvx_begin
    variable x(p);
    minimize( norm(x, 1) );
    subject to
        A*x == cb;
cvx_end
fopt = cvx_optval;
%%
% Plot the output results.
figure, subplot(121);
semilogy(abs(output_dl.hist.fx_val - fopt)/fopt, 'r'); xlabel('The objective value');
hold on
semilogy(abs(output_ol.hist.fx_val - fopt)/fopt, 'b')
semilogy(abs(output_ol_r.hist.fx_val - fopt)/fopt, 'k')
legend('double loop', 'asgard', 'asgard-restart')
subplot(122);
semilogy(output_dl.hist.rel_pfeas, 'r'); xlabel('The feasibility');
hold on
semilogy(output_ol.hist.rel_pfeas, 'b')
semilogy(output_ol_r.hist.rel_pfeas, 'k')
legend('double loop', 'asgard', 'asgard-restart')
% figure(3);
% stairs(x, 'b--'); hold on; stairs(optsol.x_opt, 'r-.');

% fprintf('The objective values: Our = %3.6f, CVX = %3.6f\n', optsol.fx_val, fopt);

