% Example in R2.
% eps*x1 - x2 <= b -> x2 >= eps*x1 - b.  
% and x2 <= -1

% Define the projections.
p        = 1000;
epsilon  = 1e-3;
a1       = [epsilon*ones(1,1); -ones(p-1,1)];  
b1       = 1;    
a2       = [0; ones(p-1,1)];         
b2       = -1;   

na1      = norm(a1,2);
na2      = norm(a2,2);
projC1   = @(x) ( x - max(a1'*x - b1, 0)*a1/(na1^2) );
projC2   = @(x) ( x - max(a2'*x - b2, 0)*a2/(na2^2) );
cb       = zeros(p, 1);

% Set the initial point.
prob.projC1 = projC1;
prob.projC2 = projC2;
v0          = ones(p, 1);
lbd0        = ones(p, 1);

% Options.
tolf        = 1e-5;
maxits      = 100000;

% Call the ADMM solver.
opts.maxiter       = maxits;
opts.tolx          = tolf;
rho                = 1;
[optsol1, output1] = ADMM_CFP(prob, v0, lbd0, rho, opts);

%% Call the SAMA solver.
% Define the proximal operators.
objFunc.nx  = 2*p;
objFunc.fxProxOper = @(x, t, varargin) [ x(1:p,1) - t*projC1( (1/t)*x(1:p,1) ); ...
                                         x(p+1:end,1) - t*projC2( (1/t)*x(p+1:end,1) )]; 
objFunc.fxFunc     = @(x, varargin) 0;

linConstr.Aoper    = @(x, varargin)  x(1:p,1) + x(p+1:end,1);
linConstr.AToper   = @(y, varargin) [y;  y];
linConstr.cb       = cb;

% Generate an initial point.
x0 = [ones(p, 1); ones(p, 1)];

% Define optional parameters.
options              = ASGARD_OptimSet([]);
options.MaxIters     = maxits;
options.RelTolFeas   = tolf;
options.saveHistMode = 2;
options.isRestart    = 0;
options.TradeOffFact = 1;

% Call the ASGARD solver.
[optsol2, output2] = ASGARD_Solver(objFunc, linConstr, x0, options);

% Call the ADSGARD solver.
[optsol3, output3] = ADSGARD_Solver(objFunc, linConstr, x0, options);


% Call the ASGARD solver with restart.
options.isRestart    = 1;
[optsol4, output4] = ASGARD_Solver(objFunc, linConstr, x0, options);

% Call the ADSGARD solver with restart.
[optsol5, output5] = ADSGARD_Solver(objFunc, linConstr, x0, options);

%% Plot the result.
figure(1);

semilogy(output2.hist.abs_pfeas, 'b--' ); hold on;
semilogy(output3.hist.abs_pfeas, 'g-.' ); hold on;
semilogy(output4.hist.abs_pfeas, 'k--' ); hold on;
semilogy(output5.hist.abs_pfeas, 'm-.' ); hold on;
semilogy(output1.hist.feas, 'r>');   hold on;

% END OF THE EXAMPLE.