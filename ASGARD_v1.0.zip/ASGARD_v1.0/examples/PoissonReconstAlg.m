function [optsol, output] = PoissonReconstAlg(inputs, U0, options, varargin)

px  = inputs.px; 
py  = inputs.py;
nx  = px*py;
mx  = inputs.mx;
if nargin < 3,       options = ASGARD_OptimSet([]); end
if isempty(options), options = ASGARD_OptimSet([]); end

% Generate data.
b      = inputs.Yf(:);
Loper  = @(u) vec( inputs.Loper( reshape(u, px, py) ) );
LToper = Loper;

% Generate the TV operator.
Doper  = @(x) gradOperator( x, px, py );
DToper = @(y) divOperator( y, px, py );

% Generate the initial point.
U0     = U0(:);
S0     = Loper(U0);
Z0     = Doper(U0);
x0     = [U0; S0; Z0];
lbu    = 0;
ubu    = 256;

% Define the inputs for solver.    
objFunc.nx         = length(x0);
objFunc.fxProxOper = @(x, gamma, varargin) fxProxOper(x, gamma, b, inputs.lambda, nx, mx, lbu, ubu);
objFunc.fxFunc     = @(x, varargin) fxEval(x, b, inputs.lambda, nx, mx);

linConstr.Aoper    = @(x, varargin) AxOper(x, Loper, Doper, nx, mx);
linConstr.AToper   = @(y, varargin) ATxOper(y, LToper, DToper, mx);
linConstr.cb       = [-1e-6*ones(length(S0),1); zeros(length(Z0), 1)];

% Call the solver.
[optsol, output] = ASGARD_Solver(objFunc, linConstr, x0, options, varargin{:});
   
end

function y = AxOper(x, Loper, Doper, nx, mx)
    u  = x(1:nx,1);
    s  = x(nx+1:nx+mx,1);
    z  = x(nx+mx+1:end,1);
    y  = [Loper(u) - s; Doper(u) - z];
end

function x = ATxOper(y, LToper, DToper, mx)
    y1 = y(1:mx,1);
    y2 = y(mx+1:end,1);
    x  = [LToper(y1) + DToper(y2); -y1; -y2];
end

function px = fxProxOper(x, gamma, b, lambda, nx, mx, lbu, ubu)

    u  = x(1:nx,1); 
    s  = x(nx+1:nx+mx,1); 
    z  = x(nx+mx+1:end,1);
    %px = [min(max(u, lbu), ubu); max(0.5*(sqrt((gamma - s).^2 + 4*gamma*b) - (gamma - s)), 1e-7); ...
    %      sign(z).*max(abs(z) - gamma*lambda, 0)];
    px = [u; 0.5*(sqrt((gamma - s).^2 + 4*gamma*b) - (gamma - s)); ...
          sign(z).*max(abs(z) - gamma*lambda, 0)];

end

function fx = fxEval(x, b, lambda, nx, mx)

    s  = x(nx+1:nx+mx,1); 
    z  = x(nx+mx+1:end,1);
    fx = sum( s - b.*log(s) ) + lambda*norm(z, 1);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% FUNCTION: [Dx, Dy] = gradOperator(f, scale)
%%% PURPOSE:  Define the gradient operator of a 2D image f.
%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = gradOperator( x, px, py )

    X  = reshape(x, px, py);

    % Compute the gradient of the images.
    Dx = [diff(X,1,2), X(:,1) - X(:,end)];
    Dy = [diff(X,1,1); X(1,:) - X(end,:)];
    
    y  = [Dx(:); Dy(:)];

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% FUNCTION: DTxyz = divOperator(x, y, scale)
%%% PURPOSE:  Define the gradient operator of a 2D image f.
%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function z = divOperator(y, px, py)
    
    X = reshape(y(1:px*py,1),     px, py);
    Y = reshape(y(px*py+1:end,1), px, py);
    
    % Compute the divergence operator of x and y.
    DTxy = [X(:,end) - X(:,1), -diff(X,1,2)] + [Y(end,:) - Y(1,:); -diff(Y,1,1)];
    
    z    = DTxy(:);
end
