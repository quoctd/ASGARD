% Example in R2.
% eps*x1 - x2 <= b -> x2 >= eps*x1 - b.  
% and x2 <= -1

% Define the projections.
e_list = [1e-1; 5e-2; 1e-2; 7.5e-3; 5e-3];
for p_run = 1:length(e_list)

    
p        = 10000;
epsilon  = e_list(p_run);
a1       = [epsilon*ones(1,1); -ones(p-1,1)];  
b1       = 1;    
a2       = [0; ones(p-1,1)];         
b2       = -1;   

na1      = norm(a1,2);
na2      = norm(a2,2);
projC1   = @(x) ( x - max(a1'*x - b1, 0)*a1/(na1^2) );
projC2   = @(x) ( x - max(a2'*x - b2, 0)*a2/(na2^2) );
cb       = zeros(p, 1);

% Set the initial point.
prob.projC1 = projC1;
prob.projC2 = projC2;
v0          = ones(p, 1);
lbd0        = ones(p, 1);

% Options.
tolf        = 1e-6;
maxits      = 100000;

% Call the ADMM solver.
opts.maxiter       = maxits;
opts.tolx          = tolf;
rho                = 1;
[optsol1, output1] = ADMM_CFP(prob, v0, lbd0, rho, opts);

%% Call the SAMA solver.
% Define the proximal operators.
objFunc.nx  = 2*p;
objFunc.fxProxOper = @(x, t, varargin) [ x(1:p,1) - t*projC1( (1/t)*x(1:p,1) ); ...
                                         x(p+1:end,1) - t*projC2( (1/t)*x(p+1:end,1) )]; 
objFunc.fxFunc     = @(x, varargin) 0;

linConstr.Aoper    = @(x, varargin)  x(1:p,1) + x(p+1:end,1);
linConstr.AToper   = @(y, varargin) [y;  y];
linConstr.cb       = cb;

% Generate an initial point.
x0 = [ones(p, 1); ones(p, 1)];

%% Define optional parameters.
options              = ASGARD_OptimSet([]);
options.MaxIters     = maxits;
options.RelTolFeas   = tolf;
options.saveHistMode = 2;
options.isRestart    = 0;
options.nRestart     = 100;

%% Call the ASGARD solver.
% [optsol2, output2] = ASGARD_Solver(objFunc, linConstr, x0, options);
[optsol2, output2] = copAsgardSolver(objFunc, linConstr, x0, options);


%% Call the ADSGARD solver.
% [optsol3, output3] = ADSGARD_Solver(objFunc, linConstr, x0, options);
[optsol3, output3] = copAdsgardSolver(objFunc, linConstr, x0, options);


%% Call the ASGARD solver with restart.
options.isRestart    = 1;
% [optsol4, output4] = ASGARD_Solver(objFunc, linConstr, x0, options);
[optsol4, output4] = copAsgardSolver(objFunc, linConstr, x0, options);

% Call the ADSGARD solver with restart.
% [optsol5, output5] = ADSGARD_Solver(objFunc, linConstr, x0, options);
[optsol5, output5] = copAdsgardSolver(objFunc, linConstr, x0, options);

%% Store the results.
store(p_run).o1 = output1;
store(p_run).o2 = output2;
store(p_run).o3 = output3;
store(p_run).o4 = output4;
store(p_run).o5 = output5;

end

%% Plot the result.
fig1 = figure(1);
semilogy(store(1).o2.hist.abs_pfeas, 'r', 'LineWidth', 3); hold on;
semilogy(store(1).o3.hist.abs_pfeas, 'm:', 'LineWidth', 4); hold on;
semilogy(store(1).o1.hist.feas, 'Color', [191, 0, 191]/255, 'LineWidth', 3);   hold on;

semilogy(store(2).o1.hist.feas, 'g--', 'LineWidth', 3);   hold on;
semilogy(store(3).o1.hist.feas, 'b:', 'LineWidth', 4);   hold on;
semilogy(store(4).o1.hist.feas, '-', 'Color', [128,128,128]/255, 'LineWidth', 4);   hold on;
semilogy(store(5).o1.hist.feas, '--', 'Color', [153,51,0]/255, 'LineWidth', 3);   hold on;
semilogy(store(5).o1.hist.feas2, '-.', 'Color', [0,191,191]/255, 'LineWidth', 4);   hold on;

xlabel('\#iteration', 'FontSize', 14, 'Interpreter', 'latex');
ylabel('$\Vert\sum_{i=1}^Nx_i\Vert_2$ in logscale', 'FontSize', 15, 'Interpreter', 'latex');
axis([-200, 32500, 0.1E-5, 500]);
h = legend('ASGARD', 'ADSGARD', 'ADMM $(\epsilon = 0.1)$', ...
           'ADMM $(\epsilon = 0.05)$', 'ADMM $(\epsilon = 0.01)$', ...
           'ADMM $(\epsilon = 0.0075)$', 'ADMM $(\epsilon = 0.005)$', 'ADMM averaging sequence');
set(h, 'FontSize', 13, 'Interpreter', 'latex'); grid on;
set(fig1, 'Color', 'w');


%% Plot the result.
fig1 = figure(2);
semilogy(store(1).o2.hist.abs_pfeas, 'r', 'LineWidth', 3); hold on;
semilogy(store(1).o3.hist.abs_pfeas, 'm:', 'LineWidth', 4); hold on;
% % semilogy(store(5).o2.hist.abs_pfeas, 'b--' ); hold on;
% % semilogy(store(5).o3.hist.abs_pfeas, 'g-.' ); hold on;
semilogy(store(5).o4.hist.abs_pfeas, 'Color', [191, 0, 191]/255, 'LineWidth', 3);   hold on;
semilogy(store(5).o5.hist.abs_pfeas, 'g--', 'LineWidth', 3);   hold on;

xlabel('\#iteration', 'FontSize', 14, 'Interpreter', 'latex');
ylabel('$\Vert\sum_{i=1}^Nx_i\Vert_2$ in logscale', 'FontSize', 15, 'Interpreter', 'latex');
axis([-200, 32500, 0.1E-5, 500]);
h = legend('ASGARD', 'ADSGARD', 'ASGARD-restart', 'ADSGARD-restart');
set(h, 'FontSize', 13, 'Interpreter', 'latex'); grid on;
set(fig1, 'Color', 'w');

% figure(1);
% 
% semilogy(store(1).o2.hist.abs_pfeas, 'b--' ); hold on;
% semilogy(store(1).o3.hist.abs_pfeas, 'g-.' ); hold on;
% semilogy(store(1).o1.hist.feas, 'r');   hold on;
% 
% 
% %semilogy(store(1).o4.hist.abs_pfeas, 'k'); hold on;
% %semilogy(store(1).o5.hist.abs_pfeas, 'k--' ); hold on;
% 
% % semilogy(store(2).o2.hist.abs_pfeas, 'b--' ); hold on;
% % semilogy(store(2).o3.hist.abs_pfeas, 'g-.' ); hold on;
% % semilogy(store(3).o2.hist.abs_pfeas, 'b--' ); hold on;
% % semilogy(store(3).o3.hist.abs_pfeas, 'g-.' ); hold on;
% % semilogy(store(4).o2.hist.abs_pfeas, 'b--' ); hold on;
% % semilogy(store(4).o3.hist.abs_pfeas, 'g-.' ); hold on;
% % semilogy(store(5).o2.hist.abs_pfeas, 'b--' ); hold on;
% % semilogy(store(5).o3.hist.abs_pfeas, 'g-.' ); hold on;
% 
% semilogy(store(2).o1.hist.feas, 'g-.');   hold on;
% semilogy(store(3).o1.hist.feas, 'b--');   hold on;
% semilogy(store(4).o1.hist.feas, 'r');   hold on;
% semilogy(store(5).o1.hist.feas, 'm--');   hold on;
% %semilogy(store(2).o1.hist.feas2, 'k-.');   hold on;
% %semilogy(store(3).o1.hist.feas2, 'k-.');   hold on;
% %semilogy(store(4).o1.hist.feas2, 'k-.');   hold on;
% semilogy(store(5).o1.hist.feas2, 'k-.');   hold on;

% END OF THE EXAMPLE.