function fx = l2wGroupNormFunc(x, w, N)

    ni = length(x)/N;
    fx = 0;
    for i=1:N
        xi     = x(1:ni,1);
        x      = x(ni+1:end,1);
        nrm_xi = norm(xi, 2);
        fx     = fx + w(i,1)*nrm_xi;
    end
    
end