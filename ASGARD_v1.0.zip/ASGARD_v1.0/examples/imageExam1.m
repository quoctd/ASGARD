% The problem is
%                   min  g(x) + r(y)
%                   s.t. B*y - x = 0.
% where g(x) = lambda*|x|_1 and r(y) = 0.5*|A*y - b|^2.              

% data_opt                = 2;
% imaddress               = 'galaxy.jpg'; % optional, only required if 4 is chosen above
% small_data_size         = 16; % optional, only required if 3 is chosen above
% 
% [x_original, ind, m, n] = get_dataset(data_opt, small_data_size, imaddress);                                
% x_original              = imresize(x_original, [n, n]);

file_name               = 'MRI_of_Knee';
%file_name               = 'MRI_brain_tumor2';
%file_name               = 'MRI-image1';
data_opt                = 4;
%imaddress               = 'galaxy.jpg'; % optional, only required if 4 is chosen above
imaddress               = [file_name, '.jpg']; %
small_data_size         = [16, 16]; % optional, only required if 3 is chosen above
[x_original, ind, m, n] = get_dataset(data_opt, small_data_size, imaddress);                                
x_original              = real(x_original);
 
% Set the optional parameters.
options               = ASGARD_OptimSet([]);
options.PrintStep     = 10;

%% Define the A=subsampled fourier and D=difference operators
Aoper                 = @(X) fft2fwd(X, ind, m, n);
AToper                = @(X) fft2adj_rectangular_new(X, ind, m, n);

Boper                 = @(X) gradOperator( X );
BToper                = @(X) divOperator( X, n );

% Compute the Lipschitz constant of ry.
LipsR                 = ASGARD_l2NormEval( size(x_original), Aoper, ...
                        AToper, options.PwMaxIters, options.PwRelTol);

                    
% The observed data and regularization parameter.
sigma                 = 1e-3;
cb                    = Aoper(x_original + sigma*randn(size(x_original)) );
lambda                = 6.0e-4;
fx_min                = 0.5*norm( Aoper(x_original) - cb, 'fro').^2 + lambda*norm(vec(Boper(x_original)), 1);

% Define an initial input.
Y0                    = zeros(size(x_original));
X0                    = Boper(Y0);

% Define the objective function and its proximal operators.
px                    = size(X0);
py                    = size(Y0);
objFunc.px            = px;
objFunc.py            = py;
objFunc.nc            = px;

soft_threshold_oper   = @(X, gamma) sign(X).*max(abs(X) - gamma, 0);
objFunc.gxProxOper    = @(X, gamma, varargin) ( soft_threshold_oper(X, lambda*gamma) );
objFunc.hyProxOper    = @(Y, gamma, varargin) ( Y );
objFunc.ryGradOper    = @(Y, varargin) ( AToper(Aoper(Y) - cb) );

objFunc.gxFunc        = @(X, varargin) ( lambda*norm(X(:), 1) );
objFunc.hyFunc        = @(Y, varargin) ( 0 );
objFunc.ryFunc        = @(Y, varargin) ( 0.5*norm( Aoper(Y) - cb, 'fro').^2 );
objFunc.ryLips        = LipsR;

linConstr.Aoper       = @(X, varargin) ( -X );
linConstr.AToper      = @(X, varargin) ( -X );
linConstr.Boper       = @(Y, varargin) ( Boper( Y ) );
linConstr.BToper      = @(Y, varargin) ( BToper(Y) );
linConstr.dlStarProx  = @(U, gamma, varargin) ( U );
linConstr.dlStarFunc  = @(U, varargin) ( norm(U, 'fro') );
linConstr.beta1       = sqrt(LB_bar);

%% User define function to compute the objective value.
objFunc.usDefFunc     = @(X, Y, varargin) 0.5*norm( Aoper(Y) - cb, 'fro').^2 + lambda*norm(vec(Boper(Y)), 1);

% Set other parameters.
LA_bar                = 1;
%LB_bar                = 1/8;
LB_bar                = ASGARD_l2NormEval(objFunc.py, linConstr.Boper, ...
                        linConstr.BToper, options.PwMaxIters, options.PwRelTol);
linConstr.LA_bar      = LA_bar;
linConstr.LB_bar      = LB_bar;

%% The PAPA solver with restart
options.saveHistMode   = 4;
options.isStoppingCond = 0;
options.MaxIters       = 100;
options.Algorithm      = 'PAPA';
options.isRestart      = 0;
options.nRestart       = 50;

%% Call our PAPA solver.
[optsol, output]       = nscvxPapa3Solver(objFunc, linConstr, X0, Y0, options);
%[optsol, output]       = scvxPapa3Solver(objFunc, linConstr, X0, Y0, options);
% Get the output image.
Xopt                   = abs(optsol.y_opt);
fx_val                 = 0.5*norm( Aoper(Xopt) - cb, 'fro').^2 + lambda*norm(vec(Boper(Xopt)), 1);

% Error to the original image.
fprintf('+ The difference bewteen the PAPA recovered and original image: %3.10f\n', ...
        norm(x_original - Xopt, 'fro')/norm(x_original, 'fro') );
fprintf('+ The objective value: %3.10f\n', fx_val);
fprintf('+ PSNR: %3.10f\n', psnr(Xopt, x_original) );
fprintf('+ Time: %3.5f\n', output.time );

%% Plot the results.
styles = {'-', '--', '-.', ':'};
colors = {'m', 'r', 'b', 'g', 'k'};
myplot = @(x) semilogy(x, 'MarkerSize', 3, 'Color', colors{randi(length(colors))}, 'LineWidth', 2, 'LineStyle', styles{randi(4)});

figure(1);
title('The real objective residual');
myplot(abs(output.hist.fx_val - fx_min)/max(1, abs(fx_min))); hold on;

figure(2);
title('The feasibility violation');
myplot(output.hist.rel_pfeas); hold on; 

% Show images.
figure(3);
subplot(2,2,1); imagesc(x_original); xlabel('Original image');
subplot(2,2,2); imagesc(Xopt); xlabel('Recovered image');

%% Call Vu-Condat's algorithm.
objFunc2.nx           = size(Y0);
soft_threshold_oper   = @(X, gamma) sign(X).*max(abs(X) - gamma, 0);
objFunc2.gxProxOper   = @(X, gamma, varargin) ( soft_threshold_oper(X, lambda*gamma) );
objFunc2.hxProxOper   = @(X, gamma, varargin) ( X );
objFunc2.rxGradOper   = @(X, varargin) ( AToper(Aoper(X) - cb) );

objFunc2.gxFunc       = @(X, varargin) ( lambda*norm(X(:), 1) );
objFunc2.hxFunc       = @(X, varargin) ( 0 );
objFunc2.rxFunc       = @(X, varargin) ( 0.5*norm( Aoper(X) - cb, 'fro').^2 );
objFunc2.rxLips       = LipsR;

linOper2.Boper        = @(Y, varargin) ( Boper( Y ) );
linOper2.BToper       = @(Y, varargin) ( BToper(Y) );

%% User define function to compute the objective value.
objFunc2.usDefFunc    = @(X, Y, varargin) 0.5*norm( Aoper(X) - cb, 'fro').^2 + lambda*norm(vec(Boper(X)), 1);

% Set other parameters.
linOper2.LB_bar       = LB_bar;

%% Call Vu-Condat's algorithm.
[optsol2, output2] = nscvxVuCondatSolver(objFunc2, linOper2, Y0, options);
Xopt2              = abs(optsol2.x_opt);
fx_val2            = 0.5*norm( Aoper(Xopt2) - cb, 'fro').^2 + lambda*norm(vec(Boper(Xopt2)), 1);

% Error to the original image.
fprintf('+ The difference bewteen the Vu-Condat recovered and original image: %3.10f\n', ...
        norm(x_original - Xopt2, 'fro')/norm(x_original, 'fro') );
fprintf('+ The objective value: %3.10f\n', fx_val2);
fprintf('+ PSNR: %3.10f\n', psnr(Xopt2, x_original) );
fprintf('+ Time: %3.5f\n', output2.time );

%% Plot the results.
figure(1);
title('The real objective residual');
myplot(abs(output2.hist.fx_val - fx_min)/max(1, abs(fx_min))); hold on;
legend('PAPA', 'Vu-Condat');

% Show images.
figure(3);
subplot(2,2,3); imagesc(x_original); xlabel('Original image');
subplot(2,2,4); imagesc(Xopt2); xlabel('Recovered image');
