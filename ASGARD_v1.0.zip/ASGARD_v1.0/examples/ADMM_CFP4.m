% FUNCTION: [xopt, output] = ADMM_CFP3(prob, v0, lbd0, rho, opts)
% PURPOSE: The implementation of ADDM to solve the convex feasibility problem
%
function [xopt, output] = ADMM_CFP4(prob, u10, u20, u30, u40, lbd0, rho, opts)
    
    % Initialization.
    time1   = tic;
    projC1  = prob.projC1;
    projC2  = prob.projC2;
    projC3  = prob.projC3;
    projC4  = prob.projC4;
    u1_cur  = u10;
    u2_cur  = u20;
    u3_cur  = u30;
    u4_cur  = u40;
    lbd_cur = lbd0;
    u1b_cur = zeros(size(u10));
    u2b_cur = zeros(size(u20));
    u3b_cur = zeros(size(u30));
    u4b_cur = zeros(size(u40));
    
    % The main loop.
    for iter = 1:opts.maxiter
        
        % Update the main iteration.
        s1_cur   = u2_cur + u3_cur + u4_cur;
        u1_next  = lbd_cur - s1_cur - (1/rho)*projC1(rho*(lbd_cur - s1_cur));
        if opts.mode == 1
            s2_cur   = u1_next + u3_cur + u4_cur;
        else
            s2_cur   = u1_cur  + u3_cur + u4_cur;
        end
        u2_next  = lbd_cur - s2_cur - (1/rho)*projC2(rho*(lbd_cur - s2_cur));
        if opts.mode == 1
            s3_cur   = u1_next + u2_next + u4_cur;
        else
            s3_cur   = u1_cur + u2_cur + u4_cur;
        end
        u3_next  = lbd_cur - s3_cur - (1/rho)*projC3(rho*(lbd_cur - s3_cur));
        if opts.mode == 1
            s4_cur   = u1_next + u2_next + u3_next;
        else
            s4_cur   = u1_cur + u2_cur + u3_cur;
        end
        u4_next  = lbd_cur - s4_cur - (1/rho)*projC4(rho*(lbd_cur - s4_cur));
        
        % Update the multiplier.
        lbd_next = lbd_cur - (u1_next + u2_next + u3_next + u4_next);
        
        % Compute the average sequence.
        u1b_cur  = (iter-1)/iter*u1b_cur + (1/iter)*u1_next;
        u2b_cur  = (iter-1)/iter*u2b_cur + (1/iter)*u2_next;
        u3b_cur  = (iter-1)/iter*u3b_cur + (1/iter)*u3_next;
        u4b_cur  = (iter-1)/iter*u4b_cur + (1/iter)*u4_next;
        n_feas2  = norm(u1b_cur + u2b_cur + u3b_cur + u4b_cur, 2);
        
        % Check the stopping criterion.
        dlbd = lbd_next - lbd_cur;
        nrm_feas = norm(dlbd, 2);
        rel_feas = nrm_feas;%/max(norm(lbd_cur, 2), 1);
        
        output.hist.feas(iter, 1)      = nrm_feas;
        output.hist.rel_feas(iter, 1)  = rel_feas;
        output.hist.feas2(iter, 1)     = n_feas2;
        
        fprintf('Iter = %4d, relFeas = %3.3e, relAvgFeas = %3.3e\n', iter, rel_feas, n_feas2);
        
        if rel_feas <= opts.tolx
            output.msg = 'Convergence acchieved!';
            break;
        end
        
        % Assign to the next iteration.
        u1_cur   = u1_next;
        u2_cur   = u2_next;
        u3_cur   = u3_next;
        u4_cur   = u4_next;
        lbd_cur = lbd_next;
    end
    
    % Get the final solution.
    xopt            = [u1_next; u2_next; u3_next];
    output.iter     = iter;
    output.feas     = nrm_feas;
    output.feas2    = n_feas2;
    output.rel_feas = rel_feas;
    output.time     = toc(time1);
end