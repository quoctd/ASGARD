% FUNCTION: ADOPT_userDefinedProc()
% PURPOSE:  Compute additional information if it is required by users.
% 
% INFORMATION:
%    By Quoc Tran-Dinh, Laboratory for Informations and Inference Systems
%       (LIONS), EPFL, Lausanne, Switzerland.
%    Date: 14.03.2014
%    Last modified: 23.04.2014
%    Contact: quoc.trandinh@epfl.ch
%
%% FUNCTION: ADOPT_userDefinedProc()

fx_val = objFunc(ub, vb);

% ADOPT v.1.0 by Quoc Tran-Dinh
% Joint work with Olivier Fercoq, and Volkan Cevher.
% Copyright 2015 Laboratory for Information and Inference Systems (LIONS)
%                EPFL Lausanne, 1015-Lausanne, Switzerland.
% See the file LICENSE for full license information.