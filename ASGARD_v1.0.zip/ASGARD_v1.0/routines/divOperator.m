%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% FUNCTION: DTxyz = divOperator(xy)
%%% PURPOSE:  Takes the vectorized and concatenated version of the
%%% gradients in both directions and then separates them and applies
%%% divergence operator.
%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Dtxy_vec] = divOperator(xy)
    
    % Reshape the vector into an image.
    n           = sqrt(length(xy) / 2);
    x_vec       = xy(1: end/2);
    y_vec       = xy(end/2 + 1: end);
    x           = reshape(x_vec, [n, n]);
    y           = reshape(y_vec, [n, n]);
    
    % Compute the divergence operator of x and y.
    DTxy        = [x(:,end) - x(:,1), -diff(x,1,2)];
    DTxy        = DTxy + [y(end,:) - y(1,:); -diff(y,1,1)];
    Dtxy_vec    = DTxy(:);
end
