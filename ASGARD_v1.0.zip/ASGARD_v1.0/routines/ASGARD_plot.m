function ASGARD_plot(data)

% Note: yData does not have same length, and is stored as cell array
np        = length(data.yData);
xData     = data.xData;
yData     = data.yData;
legendStr = data.legendStr;

options.logScale = 2;
options.colors = [];
options.lineStyles = {':','--','-'};
options.markers = {'o', 's', '*', '>', '<', '+'};%, 'd', 'p', 'h', 'v', '^', '.'};
for ii =1:np, 
    options.colors = [options.colors; rand(1,3)]; 
end

% Note: we will truncate the lower y-axis limit but not the upper limit
%options.ylimits = [1e-6 inf];

options.markerSpacing = [25 1; 25 11; 25 21; 25 5; 25 15; 25 8];%; 25 9; 25 10];

options.xlabel     = 'Iteration Number';
options.ylabel     = 'Error';
options.legend     = legendStr;
options.legendLoc  = 'SouthWest';
prettyPlot(xData,yData, options);
