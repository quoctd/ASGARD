%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% FUNCTION: [Dxy] = gradOperator(f)
%%% PURPOSE:  Define the gradient operator of a 2D image f. Vectorize and
%%% concatenate the gradients in both directions before giving the output.
%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Dxy_concat] = gradOperator( f )
    
    % Reshape the vector into an image.
    n           = sqrt(length(f));
    f_im        = reshape(f, [n, n]);
    
    % Compute the gradient of the images.
    Dx          = [diff(f_im, 1, 2), f_im(:, 1) - f_im(:, end)];
    Dy          = [diff(f_im, 1, 1); f_im(1, :) - f_im(end, :)];
    
    Dxy_concat  = [Dx(:); Dy(:)];
    
end
