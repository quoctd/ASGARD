%% FUNCTION: ASGARD_initHistory()
%  PURPOSE:  Initialize the history of the iterations.

%%% Initialize some undefined paramters ...
fx_val = nan; rel_schg = nan; rel_pfeas = nan; gamma = 0; beta = 0; tau = 0;
output.msg = ''; output.status = ''; gy_val = nan; dl_val = 0;
x_cur  = []; y_cur = [];
    
% ASGARD v.1.0 by Quoc Tran-Dinh 
% Joint work with Olivier Fercoq, and Volkan Cevher.
% Copyright 2016 Department of Statistics and Operations Research (STOR)
%                The University of North Carolina at Chapel Hill (UNC)
% See the file LICENSE for full license information.