% FUNCTION: [optsol, output] = TwoAsgardSolver(objFunc, linConstr, x0, options, varargin)
% PURPOSE: An implementation of the Two Loop ASGARD algorithm for solving 
%          constrained convex optimization problems of the form:
%                    min_x f(x) s.t. A*x = c.
%
% USAGE:
%    Inputs:
%      objFunc     : A structure that contains f, the proximal operator of f
%                    and additional fields if needed.
%      linConstr   : A structure to store the linear constraints with
%                    operators A, its adjoints and vector c.
%      x0          : An initial point
%      options     : Optional variables to control the algorithm.
%      varargin    : User defined variables if needed.
%
%    Outputs:
%      optsol      : A structure to contain the final solution.
%      output      : A structure to store other output information.
%
% REFFERENCES:
%    [1]. Q. Tran-Dinh, O. Fercoq, and V. Cevher, A Smoothing Primal-Dual 
%         Optimization Framework for Fully Nonsmooth Constrained Convex 
%         Optimization, Manuscript, 2016.
%
% INFORMATION:
%    By Quoc Tran-Dinh, Department of Statistics and Operations Research
%    The University of North Carolina at Chapel Hill (UNC).
%    Joint work with Olivier Fercoq, and Volkan Cevher.
%    Date: 08.26.2016.
%    Last modified: 08.06.2016.
%    Contact: quoctd@email.unc.edu
%
function [optsol, output] = TwoLoopAsgardSolver_sc(objFunc, linConstr, x0, options, mu, varargin)
   
% Check the inputs.
if nargin < 2,        error('Not enough inputs');    end;
if nargin < 4,        options = ASGARD_OptimSet([]); end;
if nargin < 3,        x0      = [];                  end;
if isempty(options),  options = ASGARD_OptimSet([]); end;
if ~isstruct(linConstr), error('Invalid second input');  end
if ~isstruct(objFunc),   error('Invalid first input');   end

% Get time started.
time1               = tic;

% Print the information and initialize the history list.
ASGARD_printInfo();
ASGARD_initHistory;

% Get data from inputs.
nx                  = objFunc.nx;
fxProxOper          = objFunc.fxProxOper;
fxFunc              = objFunc.fxFunc;
Aoper               = @(x) linConstr.Aoper( x, varargin{:});
AToper              = @(x) linConstr.AToper(x, varargin{:});
cb                  = linConstr.cb;
prox_g_star         = linConstr.prox_g_star;
mx                  = length(Aoper(x0));
max_nrm_c1          = max(norm(cb, 2), 1);
LA_bar              = options.LA_bar;
beta1               = options.beta1;
m_0                 = options.m_0;
alpha               = options.alpha;
mu                  = mu;

if options.constrained == 0
    reg             = options.reg;
else
    reg             = 1;
end
% Generate an initial point.
if isempty(x0), x0 = zeros(nx, 1); end

% Initialization phase.
x_tilde             = x0;
x_hat               = x0;
x_bar               = x0;

x_cur               = x0;
x_hat               = x_cur;
y_dot               = zeros(mx, 1);

tau                 = 1;
Ax_cur              = Aoper(x0);
Ax_hat              = Aoper(x0);
Ax_bar              = Ax_cur;
Ax_tilde            = Ax_cur;
beta                = beta1;
num_eps             = options.num_eps;

m_l                 = m_0;
iter                = 0; % total counter for printing

% if nargin > 4,          
%     B               = options.B;
%     q               = options.q;
%     varargin{1}     = B;
%     varargin{2}     = q;
% end

% The main loop.
for ou = 1:num_eps+1
    for kk = 1:m_l
        iter=iter+1;
        
        % Start counting cummulative time.
        time_it = tic;

        % Evaluate the objective value if required.
        if options.isFxEval, fx_val = fxFunc(x_cur); end        
        
        x_hat       = (1-tau) * x_bar + tau * x_tilde;
        Ax_hat      = (1-tau) * Ax_bar + tau* Ax_tilde;
        
        y_hat_star  = prox_g_star(y_dot + 1/beta * Ax_hat, 1/beta);
        
        % Compute the proximal operator of f and compute Ax_next.
        betaL       = beta/LA_bar;
        Aty_hats    = AToper(y_hat_star);
        x_past      = x_bar;
        
        
        x_bar       = fxProxOper( x_hat - betaL*Aty_hats, betaL, varargin{:} );
        Ax_bar      = Aoper(x_bar);
        
        x_tilde     = x_tilde - 1./tau * (x_hat - x_bar);
        Ax_tilde    = Aoper(x_tilde);
        

        % Assign variables to go to the next step.
        tau_next    = (sqrt(tau^4+4*tau^2)-tau^2)/(2);
        
        tau       = tau_next;

        % Compute the solution change (absolute and relative changes).
        x_cur = x_tilde;
        Ax_cur = Ax_tilde;
        abs_schg   = norm(x_cur - x_past, 2);
        rel_schg   = abs_schg/max(1, norm(x_past, 2));
    
        % Compute the feasibility gap (absotule and relative).
        if options.constrained == 1
            abs_pfeas  = norm( max(Ax_cur - cb, 0), 2);
            rel_pfeas  = abs_pfeas/max_nrm_c1;
        end
        
        ASGARD_saveHistory;
        ASGARD_printIteration;
    end
    
    
    beta        = beta/sqrt(alpha);
    m_l         = m_l*sqrt(alpha);
    y_dot       = prox_g_star(y_dot + 1/beta * Ax_bar, 1/beta);
    tau         = 1.0;
    x_tilde     = x_bar;
    Ax_tilde    = Ax_bar;
end
% End of the main loop.

% Finalization.
ASGARD_finalization;

% Get the final solution.
optsol.x_opt  = x_tilde;
optsol.y_opt  = y_hat_star;
optsol.fx_val = fx_val;

end

% ASGARD v.1.0 by Quoc Tran-Dinh (quoctd@email.unc.edu)
% Joint work with Olivier Fercoq, and Volkan Cevher.
% Copyright @ 2016 Department of Statistics and Operations Research (STOR)
%                The University of North Carolina at Chapel Hill (UNC)
% See the file LICENSE for full license information.